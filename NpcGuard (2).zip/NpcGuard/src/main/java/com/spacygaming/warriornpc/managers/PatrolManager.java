package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import org.bukkit.Location;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class PatrolManager {
    
    private final WarriorNPCPlugin plugin;
    private final Map<String, Integer> currentWaypointIndex = new ConcurrentHashMap<>();
    private final Map<String, Boolean> activePatrols = new ConcurrentHashMap<>();
    private final Map<String, Integer> stuckTicks = new ConcurrentHashMap<>();
    private final Map<String, Monster> combatTargets = new ConcurrentHashMap<>();
    
    public PatrolManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void addWaypoint(NPCData data, Location location) {
        data.getPatrolWaypoints().add(location);
    }
    
    public void clearWaypoints(NPCData data) {
        data.getPatrolWaypoints().clear();
        stopPatrol(data);
    }
    
    public void startPatrol(NPCData data) {
        if (data.getPatrolWaypoints().isEmpty()) return;
        
        String name = data.getName();
        activePatrols.put(name, true);
        currentWaypointIndex.put(name, 0);
        stuckTicks.put(name, 0);
        combatTargets.remove(name);
        data.setCurrentTask("PATROL");
        
        Location firstWaypoint = data.getPatrolWaypoints().get(0);
        plugin.getMovementManager().walkTo(data, firstWaypoint);
    }
    
    public void stopPatrol(NPCData data) {
        String name = data.getName();
        activePatrols.remove(name);
        currentWaypointIndex.remove(name);
        stuckTicks.remove(name);
        combatTargets.remove(name);
        plugin.getMovementManager().stopMovement(data);
    }
    
    public void tick(NPCData data) {
        if (!activePatrols.getOrDefault(data.getName(), false)) return;
        if (data.getNpcEntity() == null || !data.isAiEnabled()) return;
        if (!"PATROL".equals(data.getCurrentTask())) return;
        
        String name = data.getName();
        Player npc = data.getNpcEntity();
        
        npc.setGravity(true);
        npc.setFlying(false);
        npc.setAllowFlight(false);
        npc.setCollidable(true);
        npc.setInvulnerable(false);
        
        List<Location> waypoints = data.getPatrolWaypoints();
        if (waypoints.isEmpty()) {
            stopPatrol(data);
            return;
        }
        
        Location npcLoc = npc.getLocation();
        Monster targetMob = combatTargets.get(name);
        
        if (targetMob != null && (targetMob.isDead() || !targetMob.isValid())) {
            combatTargets.remove(name);
            targetMob = null;
        }
        
        if (targetMob == null) {
            try {
                List<Monster> nearbyMobs = npcLoc.getWorld().getNearbyEntities(npcLoc, 8, 8, 8).stream()
                    .filter(e -> e instanceof Monster)
                    .filter(e -> e.isValid() && !((Monster)e).isDead())
                    .map(e -> (Monster)e)
                    .sorted((a, b) -> Double.compare(
                        npcLoc.distance(a.getLocation()),
                        npcLoc.distance(b.getLocation())
                    ))
                    .toList();
                
                if (!nearbyMobs.isEmpty()) {
                    targetMob = nearbyMobs.get(0);
                    combatTargets.put(name, targetMob);
                }
            } catch (Exception ignored) {}
        }
        
        if (targetMob != null) {
            double distToMob = npcLoc.distance(targetMob.getLocation());
            
            if (distToMob > 15.0) {
                combatTargets.remove(name);
            } else {
                plugin.getMovementManager().lookAt(data, targetMob);
                
                if (distToMob > 3.0) {
                    npc.setSprinting(true);
                    plugin.getMovementManager().walkTo(data, targetMob);
                } else {
                    npc.setSprinting(false);
                    
                    if (npc.getAttackCooldown() >= 0.9f) {
                        targetMob.damage(2.0, npc);
                        npc.swingMainHand();
                        npc.getWorld().playSound(npcLoc, 
                            org.bukkit.Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
                    }
                }
                return;
            }
        }
        
        // No mob - continue patrol
        int currentIndex = currentWaypointIndex.getOrDefault(name, 0);
        if (currentIndex >= waypoints.size()) {
            currentIndex = 0;
            currentWaypointIndex.put(name, 0);
        }
        
        Location targetWaypoint = waypoints.get(currentIndex);
        double distance = npcLoc.distance(targetWaypoint);
        
        // Reached waypoint - move to next immediately (no wait)
        if (distance < 2.5) {
            int nextIndex = (currentIndex + 1) % waypoints.size();
            currentWaypointIndex.put(name, nextIndex);
            stuckTicks.put(name, 0);
            
            Location nextWaypoint = waypoints.get(nextIndex);
            plugin.getMovementManager().walkTo(data, nextWaypoint);
            return;
        }
        
        // Check if moving
        boolean isMoving = plugin.getMovementManager().isMoving(data);
        
        if (!isMoving) {
            int stuck = stuckTicks.getOrDefault(name, 0) + 1;
            stuckTicks.put(name, stuck);
            
            // If stuck for 40 ticks, skip waypoint
            if (stuck >= 40) {
                int nextIndex = (currentIndex + 1) % waypoints.size();
                currentWaypointIndex.put(name, nextIndex);
                stuckTicks.put(name, 0);
                
                Location nextWaypoint = waypoints.get(nextIndex);
                plugin.getMovementManager().walkTo(data, nextWaypoint);
            }
        } else {
            stuckTicks.put(name, 0);
        }
    }
    
    public boolean isPatrolling(NPCData data) {
        return activePatrols.getOrDefault(data.getName(), false);
    }
}

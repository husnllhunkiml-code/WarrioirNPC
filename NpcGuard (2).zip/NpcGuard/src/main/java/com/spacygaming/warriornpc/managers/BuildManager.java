package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;

import java.util.*;

public class BuildManager {
    
    private final WarriorNPCPlugin plugin;
    private final Map<String, BuildTask> tasks = new HashMap<>();
    
    public BuildManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void startBuilding(NPCData data, String type, Location startLocation) {
        BuildTask task = new BuildTask(type, startLocation, data.getLocation().clone());
        tasks.put(data.getName(), task);
        data.setCurrentTask("BUILD_" + type.toUpperCase());
        data.setAiEnabled(true);
    }
    
    public void tick(NPCData data) {
        Player npc = data.getNpcEntity();
        if (npc == null || !npc.isValid()) return;
        
        BuildTask task = tasks.get(data.getName());
        if (task == null) {
            npc.sendMessage("§c[DEBUG] No build task found!");
            return;
        }
        
        npc.setGravity(true);
        npc.setInvulnerable(true);
        
        // Debug message every 20 ticks
        if (task.currentIndex % 20 == 0) {
            npc.getWorld().getPlayers().forEach(p -> 
                p.sendMessage("§7[BUILD] " + data.getName() + " - Block " + task.currentIndex + "/" + task.blocks.size())
            );
        }
        
        if (task.isComplete()) {
            tasks.remove(data.getName());
            data.setCurrentTask("IDLE");
            npc.setInvulnerable(false);
            
            plugin.getMovementManager().walkTo(data, task.originalLocation);
            npc.getWorld().playSound(npc.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
            return;
        }
        
        BlockData nextBlock = task.getNext();
        if (nextBlock == null) return;
        
        Location target = nextBlock.location.clone().add(0.5, 0, 0.5);
        double dist = npc.getLocation().distance(target);
        
        if (dist > 3.5) {
            plugin.getMovementManager().walkTo(data, target);
        } else {
            plugin.getMovementManager().stopMovement(data);
            plugin.getMovementManager().lookAt(data, nextBlock.location);
            
            task.tickDelay++;
            if (task.tickDelay >= 10) {
                task.tickDelay = 0;
                nextBlock.place();
                task.currentIndex++;
                npc.swingMainHand();
                npc.getWorld().playSound(nextBlock.location, org.bukkit.Sound.BLOCK_STONE_PLACE, 0.8f, 1.0f);
            }
        }
    }
    
    private static class BuildTask {
        final List<BlockData> blocks;
        final Location originalLocation;
        int currentIndex = 0;
        int tickDelay = 0;
        
        BuildTask(String type, Location start, Location original) {
            this.originalLocation = original;
            this.blocks = generate(type, start);
        }
        
        BlockData getNext() {
            return currentIndex < blocks.size() ? blocks.get(currentIndex) : null;
        }
        
        boolean isComplete() {
            return currentIndex >= blocks.size();
        }
        
        List<BlockData> generate(String type, Location start) {
            List<BlockData> list = new ArrayList<>();
            Location base = start.clone();
            base.setY(start.getWorld().getHighestBlockYAt(start) + 1);
            
            switch (type.toLowerCase()) {
                case "house" -> house(list, base);
                case "tower" -> tower(list, base);
                case "castle" -> castle(list, base);
                case "shelter" -> shelter(list, base);
            }
            return list;
        }
        
        void house(List<BlockData> list, Location s) {
            // Floor
            for (int x = 0; x < 5; x++)
                for (int z = 0; z < 5; z++)
                    list.add(new BlockData(s.clone().add(x, 0, z), Material.OAK_PLANKS));
            
            // Walls
            for (int y = 1; y <= 3; y++) {
                for (int x = 0; x < 5; x++) {
                    for (int z = 0; z < 5; z++) {
                        if (x == 0 || x == 4 || z == 0 || z == 4) {
                            if (y <= 2 && x == 2 && z == 0) continue; // Door
                            Material mat = (y == 2 && (x == 1 || x == 3) && (z == 0 || z == 4)) ? Material.GLASS_PANE : Material.OAK_PLANKS;
                            list.add(new BlockData(s.clone().add(x, y, z), mat));
                        }
                    }
                }
            }
            
            // Roof
            for (int x = -1; x <= 5; x++) {
                for (int z = -1; z <= 5; z++) {
                    int dist = Math.max(Math.abs(x - 2), Math.abs(z - 2));
                    if (dist <= 3)
                        list.add(new BlockData(s.clone().add(x, 4, z), Material.OAK_PLANKS));
                }
            }
        }
        
        void tower(List<BlockData> list, Location s) {
            for (int y = 0; y < 12; y++)
                for (int x = 0; x < 3; x++)
                    for (int z = 0; z < 3; z++)
                        if (y == 0 || x == 0 || x == 2 || z == 0 || z == 2)
                            list.add(new BlockData(s.clone().add(x, y, z), Material.STONE_BRICKS));
            
            for (int x = -1; x <= 3; x++)
                for (int z = -1; z <= 3; z++)
                    list.add(new BlockData(s.clone().add(x, 12, z), Material.STONE_BRICKS));
        }
        
        void castle(List<BlockData> list, Location s) {
            for (int y = 0; y < 6; y++) {
                for (int x = 0; x < 12; x++) {
                    for (int z = 0; z < 12; z++) {
                        if (x == 0 || x == 11 || z == 0 || z == 11) {
                            if (y <= 2 && x == 5 && z == 0) continue; // Gate
                            list.add(new BlockData(s.clone().add(x, y, z), Material.STONE_BRICKS));
                        } else if (y == 0) {
                            list.add(new BlockData(s.clone().add(x, y, z), Material.COBBLESTONE));
                        }
                    }
                }
            }
            
            // Towers
            int[][] corners = {{0, 0}, {0, 10}, {10, 0}, {10, 10}};
            for (int[] c : corners)
                for (int y = 6; y < 10; y++)
                    for (int dx = 0; dx < 2; dx++)
                        for (int dz = 0; dz < 2; dz++)
                            list.add(new BlockData(s.clone().add(c[0] + dx, y, c[1] + dz), Material.STONE_BRICKS));
        }
        
        void shelter(List<BlockData> list, Location s) {
            for (int x = 0; x < 4; x++) {
                for (int z = 0; z < 4; z++) {
                    list.add(new BlockData(s.clone().add(x, 0, z), Material.COBBLESTONE));
                    if (x == 0 || x == 3 || z == 0 || z == 3) {
                        if (!(x == 1 && z == 0)) { // Door
                            list.add(new BlockData(s.clone().add(x, 1, z), Material.COBBLESTONE));
                            list.add(new BlockData(s.clone().add(x, 2, z), Material.COBBLESTONE));
                        }
                    }
                }
            }
            for (int x = 0; x < 4; x++)
                for (int z = 0; z < 4; z++)
                    list.add(new BlockData(s.clone().add(x, 3, z), Material.COBBLESTONE));
        }
    }
    
    private static class BlockData {
        final Location location;
        final Material material;
        
        BlockData(Location location, Material material) {
            this.location = location;
            this.material = material;
        }
        
        void place() {
            Block block = location.getBlock();
            if (block.getType().isAir() || block.getType() == Material.SHORT_GRASS || 
                block.getType() == Material.TALL_GRASS || block.getType() == Material.FERN) {
                block.setType(material);
            }
        }
    }
}

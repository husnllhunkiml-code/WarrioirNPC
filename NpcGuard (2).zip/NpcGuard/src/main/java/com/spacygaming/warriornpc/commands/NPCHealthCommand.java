package com.spacygaming.warriornpc.commands;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public class NPCHealthCommand {
    
    private final WarriorNPCPlugin plugin;
    
    public NPCHealthCommand(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void handleSetHealth(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /wnpc health <npc> <amount>");
            return;
        }
        
        String name = args[1];
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        try {
            double health = Double.parseDouble(args[2]);
            if (health <= 0 || health > 2048) {
                sender.sendMessage("Health must be between 1 and 2048!");
                return;
            }
            
            data.setHealth(health);
            
            Player npc = data.getNpcEntity();
            if (npc != null) {
                npc.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).setBaseValue(health);
                npc.setHealth(health);
            }
            
            Map<String, String> healthMap = new HashMap<>();
            healthMap.put("npc", name);
            healthMap.put("health", String.format("%.1f", health));
            sender.sendMessage("§aSet health of §e" + name + " §ato §e" + health + " §ahearts");
            
        } catch (NumberFormatException e) {
            sender.sendMessage("Invalid health value!");
        }
    }
}

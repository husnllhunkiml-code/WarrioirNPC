package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class MessageManager {
    
    private final WarriorNPCPlugin plugin;
    private FileConfiguration messages;
    private String prefix;
    
    public MessageManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
        reload();
    }
    
    public void reload() {
        File messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        messages = YamlConfiguration.loadConfiguration(messagesFile);
        prefix = color(messages.getString("prefix", "&8[&cWarriorNPC&8]&r"));
    }
    
    public void send(CommandSender sender, String key, Map<String, String> replacements) {
        String message = messages.getString(key, key);
        if (replacements != null) {
            for (Map.Entry<String, String> entry : replacements.entrySet()) {
                message = message.replace("{" + entry.getKey() + "}", entry.getValue());
            }
        }
        sender.sendMessage(prefix + " " + color(message));
    }
    
    public void send(CommandSender sender, String key) {
        send(sender, key, null);
    }
    
    public void send(CommandSender sender, String key, String placeholder, String value) {
        Map<String, String> map = new HashMap<>();
        map.put(placeholder, value);
        send(sender, key, map);
    }
    
    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}

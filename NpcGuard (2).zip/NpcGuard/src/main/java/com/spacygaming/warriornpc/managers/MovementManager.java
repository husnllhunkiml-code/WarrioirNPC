package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import net.citizensnpcs.api.ai.Navigator;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

public class MovementManager {
    
    private final WarriorNPCPlugin plugin;
    private final Map<String, Location> targetLocations = new HashMap<>();
    private final Map<String, Entity> followTargets = new HashMap<>();
    
    public MovementManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void walkTo(NPCData data, Location target) {
        NPC npc = getCitizenNPC(data);
        if (npc == null || !npc.isSpawned()) return;
        
        Player player = data.getNpcEntity();
        if (player != null) {
            player.setGravity(true);
            player.setFlying(false);
            player.setAllowFlight(false);
        }
        
        Navigator navigator = npc.getNavigator();
        navigator.cancelNavigation();
        navigator.setTarget(target);
        navigator.getLocalParameters().speedModifier(1.3f);
        navigator.getLocalParameters().stuckAction(null);
        navigator.getLocalParameters().distanceMargin(0.5);
        navigator.getLocalParameters().updatePathRate(1);
        navigator.getLocalParameters().avoidWater(true);
        navigator.getLocalParameters().useNewPathfinder(true);
        
        targetLocations.put(data.getName(), target);
    }
    
    public void walkTo(NPCData data, Entity target) {
        NPC npc = getCitizenNPC(data);
        if (npc == null || !npc.isSpawned() || target == null) return;
        
        Player player = data.getNpcEntity();
        if (player != null) {
            player.setGravity(true);
            player.setFlying(false);
            player.setAllowFlight(false);
            player.setSprinting(true);
            
            if (!player.getWorld().equals(target.getWorld())) {
                return;
            }
        }
        
        Navigator navigator = npc.getNavigator();
        
        if (!navigator.isNavigating() || navigator.getEntityTarget() == null || 
            !target.equals(navigator.getEntityTarget().getTarget())) {
            navigator.cancelNavigation();
            navigator.setTarget(target, true);
            navigator.getLocalParameters().speedModifier(1.8f);
            navigator.getLocalParameters().attackRange(plugin.getConfigManager().getAttackRange());
            navigator.getLocalParameters().distanceMargin(0.5);
            navigator.getLocalParameters().stationaryTicks(5);
            navigator.getLocalParameters().updatePathRate(1);
            navigator.getLocalParameters().avoidWater(true);
            navigator.getLocalParameters().useNewPathfinder(true);
            navigator.getDefaultParameters().baseSpeed(1.8f);
        }
        
        followTargets.put(data.getName(), target);
    }
    
    public void followEntity(NPCData data, Entity target) {
        NPC npc = getCitizenNPC(data);
        if (npc == null || !npc.isSpawned() || target == null) return;
        
        Player player = data.getNpcEntity();
        if (player != null) {
            player.setGravity(true);
            player.setFlying(false);
            player.setAllowFlight(false);
            player.setCollidable(true);
        }
        
        Navigator navigator = npc.getNavigator();
        
        if (!navigator.isNavigating() || navigator.getEntityTarget() == null || 
            !target.equals(navigator.getEntityTarget().getTarget())) {
            navigator.cancelNavigation();
            navigator.setTarget(target, false);
            
            net.citizensnpcs.api.ai.NavigatorParameters params = navigator.getLocalParameters();
            params.baseSpeed(1.4f);
            params.speedModifier(1.4f);
            params.range(500.0f);
            params.distanceMargin(3.5);
            params.stationaryTicks(20);
            params.updatePathRate(3);
            params.useNewPathfinder(true);
            params.avoidWater(true);
        }
        
        followTargets.put(data.getName(), target);
    }
    
    public void sprint(NPCData data, boolean enable) {
        Player player = data.getNpcEntity();
        if (player != null) {
            player.setSprinting(enable);
        }
    }
    
    public void stopMovement(NPCData data) {
        NPC npc = getCitizenNPC(data);
        if (npc != null && npc.isSpawned()) {
            npc.getNavigator().cancelNavigation();
        }
        targetLocations.remove(data.getName());
    }
    
    public void stopFollow(NPCData data) {
        followTargets.remove(data.getName());
        stopMovement(data);
    }
    
    public boolean isFollowing(NPCData data) {
        return followTargets.containsKey(data.getName());
    }
    
    public boolean isMoving(NPCData data) {
        NPC npc = getCitizenNPC(data);
        if (npc == null) return false;
        
        return npc.getNavigator().isNavigating();
    }
    
    public boolean hasReachedTarget(NPCData data) {
        NPC npc = getCitizenNPC(data);
        if (npc == null) return false;
        
        Navigator nav = npc.getNavigator();
        return !nav.isNavigating() && targetLocations.containsKey(data.getName());
    }
    
    public void lookAt(NPCData data, Location target) {
        Player player = data.getNpcEntity();
        if (player == null) return;
        
        Location eyeLoc = player.getEyeLocation();
        Location direction = target.clone();
        
        double dx = direction.getX() - eyeLoc.getX();
        double dy = direction.getY() - eyeLoc.getY();
        double dz = direction.getZ() - eyeLoc.getZ();
        
        double distXZ = Math.sqrt(dx * dx + dz * dz);
        
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) Math.toDegrees(Math.atan(-dy / distXZ));
        
        Location newLoc = player.getLocation().clone();
        newLoc.setYaw(yaw);
        newLoc.setPitch(pitch);
        
        player.teleport(newLoc);
    }
    
    public void lookAt(NPCData data, Entity target) {
        if (target != null) {
            lookAt(data, target.getLocation().clone().add(0, target.getHeight() / 2, 0));
        }
    }
    
    public double getDistanceTo(NPCData data, Location target) {
        Player player = data.getNpcEntity();
        if (player == null) return Double.MAX_VALUE;
        
        return player.getLocation().distance(target);
    }
    
    public double getDistanceTo(NPCData data, Entity target) {
        Player player = data.getNpcEntity();
        if (player == null || target == null) return Double.MAX_VALUE;
        
        return player.getLocation().distance(target.getLocation());
    }
    
    public Location getTargetLocation(NPCData data) {
        return targetLocations.get(data.getName());
    }
    
    public Entity getFollowTarget(NPCData data) {
        return followTargets.get(data.getName());
    }
    
    private NPC getCitizenNPC(NPCData data) {
        Player player = data.getNpcEntity();
        if (player == null) return null;
        
        return net.citizensnpcs.api.CitizensAPI.getNPCRegistry().getNPC(player);
    }
}

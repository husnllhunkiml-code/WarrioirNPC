package com.spacygaming.warriornpc.commands;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.combat.FightStyle;
import com.spacygaming.warriornpc.models.NPCData;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public class NPCTabCompleter implements TabCompleter {
    
    private final WarriorNPCPlugin plugin;
    
    public NPCTabCompleter(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();
        
        if (args.length == 1) {
            completions.addAll(Arrays.asList(
                "spawn", "remove", "list", "info", "tp", "tphere", "goto", "follow",
                "attack", "duel", "fight", "guard", "patrol", "build", "style",
                "wear", "clearwear", "start", "stop", "rename", "reloadskin", 
                "reset", "reload", "health", "inventory", "inv", "resumeallnpc", "team"
            ));
            return filterCompletions(completions, args[0]);
        }
        
        String subCommand = args[0].toLowerCase();
        
        switch (subCommand) {
            case "spawn" -> {
                if (args.length == 2) {
                    completions.addAll(Arrays.asList("Steve", "Alex", "Notch", "Herobrine", "Guard", "Warrior"));
                }
            }
            case "remove", "info", "rename", "reloadskin", "reset", "clearwear" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                }
            }
            case "tphere" -> {
                if (args.length == 2) {
                    completions.add("all");
                    completions.addAll(getNPCNames());
                }
            }
            case "tp" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                } else if (args.length >= 3 && args.length <= 5) {
                    if (sender instanceof Player player) {
                        completions.add(String.valueOf((int) player.getLocation().getX()));
                        completions.add(String.valueOf((int) player.getLocation().getY()));
                        completions.add(String.valueOf((int) player.getLocation().getZ()));
                    }
                }
            }
            case "goto" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                } else if (args.length >= 3 && args.length <= 5) {
                    if (sender instanceof Player player) {
                        completions.add(String.valueOf((int) player.getLocation().getX()));
                        completions.add(String.valueOf((int) player.getLocation().getY()));
                        completions.add(String.valueOf((int) player.getLocation().getZ()));
                    }
                }
            }
            case "follow" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                } else if (args.length == 3) {
                    completions.addAll(getPlayerNames());
                    completions.addAll(getNPCNames());
                }
            }
            case "attack" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                } else if (args.length >= 3) {
                    completions.addAll(getPlayerNames());
                    completions.addAll(getNPCNames());
                }
            }
            case "duel" -> {
                if (args.length == 2 || args.length == 3) {
                    completions.addAll(getNPCNames());
                }
            }
            case "fight" -> {
                if (args.length == 2) {
                    completions.add("team:");
                } else if (args.length == 3) {
                    completions.add("vs");
                } else if (args.length == 4) {
                    completions.add("team:");
                }
            }
            case "guard" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                } else if (args.length == 3) {
                    completions.addAll(Arrays.asList("5", "10", "15", "20", "25"));
                }
            }
            case "patrol" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                } else if (args.length == 3) {
                    completions.addAll(Arrays.asList("add", "start", "list", "clear"));
                }
            }
            case "build" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                } else if (args.length == 3) {
                    completions.addAll(Arrays.asList("house", "castle", "tower", "shelter"));
                }
            }
            case "style" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                } else if (args.length == 3) {
                    completions.addAll(Arrays.asList("attack", "defense"));
                } else if (args.length == 4) {
                    completions.addAll(Arrays.stream(FightStyle.values())
                        .map(Enum::name)
                        .collect(Collectors.toList()));
                }
            }
            case "wear" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                } else if (args.length == 3) {
                    completions.addAll(Arrays.asList("hand", "offhand", "helmet", "chest", "legs", "boots"));
                }
            }
            case "start", "stop" -> {
                if (args.length == 2) {
                    completions.add("all");
                    completions.addAll(getNPCNames());
                }
            }
            case "health" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                } else if (args.length == 3) {
                    completions.addAll(Arrays.asList("10", "20", "40", "60", "100", "200", "500", "1000"));
                }
            }
            case "inventory", "inv" -> {
                if (args.length == 2) {
                    completions.addAll(getNPCNames());
                }
            }
            case "team" -> {
                if (args.length == 2) {
                    completions.addAll(Arrays.asList("create", "delete", "add", "addallnpc", "remove", "list", "info", "war", "respawn"));
                } else if (args.length == 3) {
                    String action = args[1].toLowerCase();
                    switch (action) {
                        case "delete", "info", "respawn", "addallnpc" -> completions.addAll(getTeamNames());
                        case "add" -> completions.addAll(getTeamNames());
                        case "remove" -> completions.addAll(getAllTeamMembers());
                        case "war" -> completions.addAll(getTeamNames());
                    }
                } else if (args.length == 4) {
                    String action = args[1].toLowerCase();
                    if (action.equals("add")) {
                        String teamName = args[2];
                        // Only show NPCs and players NOT already in ANY team
                        completions.addAll(getAvailableMembers());
                    } else if (action.equals("war")) {
                        // Show teams except the first one
                        String firstTeam = args[2];
                        completions.addAll(getTeamNames().stream()
                            .filter(t -> !t.equalsIgnoreCase(firstTeam))
                            .collect(Collectors.toList()));
                    }
                }
            }
        }
        
        return filterCompletions(completions, args[args.length - 1]);
    }
    
    private List<String> getNPCNames() {
        return plugin.getNpcManager().getAllNPCs().stream()
            .map(NPCData::getName)
            .collect(Collectors.toList());
    }
    
    private List<String> getPlayerNames() {
        return Bukkit.getOnlinePlayers().stream()
            .map(Player::getName)
            .collect(Collectors.toList());
    }
    
    private List<String> filterCompletions(List<String> completions, String input) {
        return completions.stream()
            .filter(s -> s.toLowerCase().startsWith(input.toLowerCase()))
            .sorted()
            .collect(Collectors.toList());
    }
    
    private List<String> getTeamNames() {
        return plugin.getTeamManager().getAllTeams().stream()
            .map(team -> team.name)
            .collect(Collectors.toList());
    }
    
    private List<String> getAllTeamMembers() {
        Set<String> members = new HashSet<>();
        for (var team : plugin.getTeamManager().getAllTeams()) {
            members.addAll(team.members);
        }
        return new ArrayList<>(members);
    }
    
    private List<String> getAvailableMembers() {
        // Get all NPCs and online players
        Set<String> all = new HashSet<>();
        all.addAll(getNPCNames());
        all.addAll(getPlayerNames());
        
        // Remove those already in teams
        Set<String> inTeams = new HashSet<>();
        for (var team : plugin.getTeamManager().getAllTeams()) {
            inTeams.addAll(team.members);
        }
        
        all.removeAll(inTeams);
        return new ArrayList<>(all);
    }
}

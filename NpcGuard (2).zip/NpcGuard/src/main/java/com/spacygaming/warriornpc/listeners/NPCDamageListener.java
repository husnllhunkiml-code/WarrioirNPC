package com.spacygaming.warriornpc.listeners;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.util.Vector;

public class NPCDamageListener implements Listener {
    
    private final WarriorNPCPlugin plugin;
    
    public NPCDamageListener(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onNPCDamage(EntityDamageByEntityEvent event) {
        if (event.isCancelled()) return;
        
        Entity damaged = event.getEntity();
        Entity damager = event.getDamager();
        
        if (damaged instanceof Player damagedPlayer) {
            NPC npc = CitizensAPI.getNPCRegistry().getNPC(damagedPlayer);
            if (npc != null) {
                NPCData data = findNPCData(damagedPlayer);
                if (data != null) {
                    damagedPlayer.setGravity(true);
                    damagedPlayer.setFlying(false);
                    damagedPlayer.setAllowFlight(false);
                    damagedPlayer.setInvulnerable(false);
                    
                    // Stronger knockback for WAR mode
                    double knockbackStrength = "WAR".equals(data.getCurrentTask()) ? 0.8 : 0.6;
                    
                    org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                        applyKnockback(damagedPlayer, damager, knockbackStrength);
                    }, 1L);
                    
                    double newHealth = Math.max(0.0, damagedPlayer.getHealth() - event.getFinalDamage());
                    data.setHealth(newHealth);
                }
            }
        }
        
        if (damager instanceof Player damagerPlayer) {
            NPC npc = CitizensAPI.getNPCRegistry().getNPC(damagerPlayer);
            if (npc != null && damaged instanceof LivingEntity target) {
                if (target instanceof Player targetPlayer) {
                    targetPlayer.setGravity(true);
                    targetPlayer.setFlying(false);
                    targetPlayer.setAllowFlight(false);
                    targetPlayer.setInvulnerable(false);
                }
                
                // Check if attacker is in WAR mode for stronger knockback
                NPCData attackerData = findNPCData(damagerPlayer);
                double knockbackStrength = (attackerData != null && "WAR".equals(attackerData.getCurrentTask())) ? 0.8 : 0.6;
                
                org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    applyKnockback(target, damagerPlayer, knockbackStrength);
                }, 1L);
            }
        }
    }
    
    private void applyKnockback(LivingEntity target, Entity attacker, double strength) {
        if (target == null || attacker == null || !target.isValid()) return;
        if (!target.getLocation().getWorld().equals(attacker.getLocation().getWorld())) return;
        
        try {
            // Ensure target can receive knockback
            if (target instanceof Player player) {
                player.setFlying(false);
                player.setGravity(true);
                player.setAllowFlight(false);
                player.setInvulnerable(false);
            }
            
            Vector direction = target.getLocation().toVector()
                .subtract(attacker.getLocation().toVector());
            
            double length = direction.length();
            if (length == 0 || !Double.isFinite(length)) {
                direction = new Vector(0, 0, 1);
            } else {
                direction = direction.normalize();
            }
            
            // Apply knockback with upward force - increased strength
            final Vector finalDirection = direction.multiply(strength).setY(0.4);
            
            if (Double.isFinite(finalDirection.getX()) && 
                Double.isFinite(finalDirection.getY()) && 
                Double.isFinite(finalDirection.getZ())) {
                
                // Apply velocity immediately
                target.setVelocity(finalDirection);
            }
        } catch (Exception e) {
            // Silently ignore knockback errors
        }
    }
    
    private NPCData findNPCData(Player player) {
        for (NPCData data : plugin.getNpcManager().getAllNPCs()) {
            if (data.getNpcEntity() != null && data.getNpcEntity().equals(player)) {
                return data;
            }
        }
        return null;
    }
}

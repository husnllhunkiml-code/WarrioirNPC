package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import org.bukkit.Bukkit;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class TeamManager {
    
    private final WarriorNPCPlugin plugin;
    private final Map<String, Team> teams = new ConcurrentHashMap<>();
    private final Map<String, String> memberToTeam = new ConcurrentHashMap<>();
    private WarState activeWar = null;
    
    public TeamManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public boolean createTeam(String name) {
        if (teams.containsKey(name.toLowerCase())) return false;
        teams.put(name.toLowerCase(), new Team(name));
        return true;
    }
    
    public boolean deleteTeam(String name) {
        Team team = teams.remove(name.toLowerCase());
        if (team == null) return false;
        
        for (String member : team.members) {
            memberToTeam.remove(member);
        }
        return true;
    }
    
    public boolean addMember(String teamName, String memberName) {
        Team team = teams.get(teamName.toLowerCase());
        if (team == null) return false;
        
        // Remove from old team if exists
        String oldTeam = memberToTeam.get(memberName);
        if (oldTeam != null) {
            Team old = teams.get(oldTeam);
            if (old != null) old.members.remove(memberName);
        }
        
        team.members.add(memberName);
        memberToTeam.put(memberName, teamName.toLowerCase());
        
        // Set NPC to TEAM state
        NPCData npc = plugin.getNpcManager().getNPC(memberName);
        if (npc != null) {
            npc.setCurrentTask("TEAM");
            npc.setAiEnabled(false); // AI off until war starts
        }
        
        return true;
    }
    
    public boolean removeMember(String memberName) {
        String teamName = memberToTeam.remove(memberName);
        if (teamName == null) return false;
        
        Team team = teams.get(teamName);
        if (team != null) {
            team.members.remove(memberName);
        }
        
        // Reset NPC state
        NPCData npc = plugin.getNpcManager().getNPC(memberName);
        if (npc != null) {
            npc.setCurrentTask("IDLE");
            npc.setAiEnabled(true);
        }
        
        return true;
    }
    
    public Team getTeam(String name) {
        return teams.get(name.toLowerCase());
    }
    
    public String getMemberTeam(String memberName) {
        return memberToTeam.get(memberName);
    }
    
    public Collection<Team> getAllTeams() {
        return teams.values();
    }
    
    public boolean startWar(String team1Name, String team2Name) {
        Team team1 = teams.get(team1Name.toLowerCase());
        Team team2 = teams.get(team2Name.toLowerCase());
        
        if (team1 == null || team2 == null) return false;
        if (team1.members.isEmpty() || team2.members.isEmpty()) return false;
        if (activeWar != null) return false;
        
        activeWar = new WarState(team1, team2);
        
        // Set all NPCs to combat mode
        for (String member : team1.members) {
            NPCData npc = plugin.getNpcManager().getNPC(member);
            if (npc != null && npc.getNpcEntity() != null) {
                npc.setAiEnabled(true);
                npc.setCurrentTask("WAR");
                
                List<LivingEntity> targets = new ArrayList<>();
                for (String enemy : team2.members) {
                    NPCData enemyNpc = plugin.getNpcManager().getNPC(enemy);
                    if (enemyNpc != null && enemyNpc.getNpcEntity() != null) {
                        targets.add(enemyNpc.getNpcEntity());
                    } else {
                        Player player = Bukkit.getPlayer(enemy);
                        if (player != null && player.isOnline()) {
                            targets.add(player);
                        }
                    }
                }
                plugin.getCombatManager().setTargets(npc, targets);
            }
        }
        
        for (String member : team2.members) {
            NPCData npc = plugin.getNpcManager().getNPC(member);
            if (npc != null && npc.getNpcEntity() != null) {
                npc.setAiEnabled(true);
                npc.setCurrentTask("WAR");
                
                List<LivingEntity> targets = new ArrayList<>();
                for (String enemy : team1.members) {
                    NPCData enemyNpc = plugin.getNpcManager().getNPC(enemy);
                    if (enemyNpc != null && enemyNpc.getNpcEntity() != null) {
                        targets.add(enemyNpc.getNpcEntity());
                    } else {
                        Player player = Bukkit.getPlayer(enemy);
                        if (player != null && player.isOnline()) {
                            targets.add(player);
                        }
                    }
                }
                plugin.getCombatManager().setTargets(npc, targets);
            }
        }
        
        return true;
    }
    
    public void handleDeath(String memberName) {
        if (activeWar == null) return;
        
        String teamName = memberToTeam.get(memberName);
        if (teamName == null) return;
        
        activeWar.recordDeath(memberName, teamName.toLowerCase());
        
        // Check if war should end
        checkWarEnd();
    }
    
    public void handleKill(String killerName, String victimName) {
        if (activeWar == null) return;
        activeWar.recordKill(killerName);
    }
    
    private void checkWarEnd() {
        if (activeWar == null) return;
        
        int team1Alive = activeWar.getAliveCount(activeWar.team1.name);
        int team2Alive = activeWar.getAliveCount(activeWar.team2.name);
        
        if (team1Alive == 0 || team2Alive == 0) {
            endWar();
        }
    }
    
    private void endWar() {
        if (activeWar == null) return;
        
        String winner = activeWar.getWinner();
        Map<String, Integer> killStats = activeWar.getKillStats();
        
        // Broadcast results
        Bukkit.broadcastMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        Bukkit.broadcastMessage("§e§l⚔ WAR ENDED ⚔");
        Bukkit.broadcastMessage("");
        Bukkit.broadcastMessage("§a§l✓ WINNER: §e" + winner);
        Bukkit.broadcastMessage("");
        Bukkit.broadcastMessage("§6§lKILL STATISTICS:");
        
        List<Map.Entry<String, Integer>> sorted = new ArrayList<>(killStats.entrySet());
        sorted.sort((a, b) -> b.getValue().compareTo(a.getValue()));
        
        for (int i = 0; i < Math.min(10, sorted.size()); i++) {
            Map.Entry<String, Integer> entry = sorted.get(i);
            String prefix = i == 0 ? "§6§l#1" : i == 1 ? "§e§l#2" : i == 2 ? "§f§l#3" : "§7#" + (i + 1);
            
            Player player = Bukkit.getPlayer(entry.getKey());
            String type = player != null ? "§b[PLAYER]" : "§7[NPC]";
            
            Bukkit.broadcastMessage(prefix + " " + type + " §f" + entry.getKey() + " §7- §c" + entry.getValue() + " kills");
        }
        
        Bukkit.broadcastMessage("");
        Bukkit.broadcastMessage("§7Total Kills: §e" + activeWar.getTotalKills());
        Bukkit.broadcastMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        
        // Clear all combat states
        for (String member : activeWar.team1.members) {
            NPCData npc = plugin.getNpcManager().getNPC(member);
            if (npc != null) {
                plugin.getCombatManager().clearTargets(npc);
                npc.setCurrentTask("TEAM");
                npc.setAiEnabled(false);
            }
        }
        
        for (String member : activeWar.team2.members) {
            NPCData npc = plugin.getNpcManager().getNPC(member);
            if (npc != null) {
                plugin.getCombatManager().clearTargets(npc);
                npc.setCurrentTask("TEAM");
                npc.setAiEnabled(false);
            }
        }
        
        activeWar = null;
    }
    
    public boolean respawnTeam(String teamName) {
        Team team = teams.get(teamName.toLowerCase());
        if (team == null) return false;
        
        int count = 0;
        for (String member : team.members) {
            NPCData npc = plugin.getNpcManager().getNPC(member);
            if (npc != null && npc.getNpcEntity() != null) {
                Player entity = npc.getNpcEntity();
                if (entity.isDead() || !entity.isValid()) {
                    entity.setHealth(entity.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).getValue());
                    count++;
                }
            }
        }
        
        return count > 0;
    }
    
    public WarState getActiveWar() {
        return activeWar;
    }
    
    public boolean isInWar() {
        return activeWar != null;
    }
    
    public static class Team {
        public final String name;
        public final Set<String> members = new HashSet<>();
        
        public Team(String name) {
            this.name = name;
        }
    }
    
    public static class WarState {
        public final Team team1;
        public final Team team2;
        private final Set<String> dead = new HashSet<>();
        private final Map<String, Integer> kills = new HashMap<>();
        
        public WarState(Team team1, Team team2) {
            this.team1 = team1;
            this.team2 = team2;
        }
        
        public void recordDeath(String member, String teamName) {
            dead.add(member);
        }
        
        public void recordKill(String killer) {
            kills.put(killer, kills.getOrDefault(killer, 0) + 1);
        }
        
        public int getAliveCount(String teamName) {
            Team team = teamName.equalsIgnoreCase(team1.name) ? team1 : team2;
            int alive = 0;
            for (String member : team.members) {
                if (!dead.contains(member)) {
                    alive++;
                }
            }
            return alive;
        }
        
        public String getWinner() {
            int t1Alive = getAliveCount(team1.name);
            int t2Alive = getAliveCount(team2.name);
            
            if (t1Alive > t2Alive) return team1.name;
            if (t2Alive > t1Alive) return team2.name;
            return "DRAW";
        }
        
        public Map<String, Integer> getKillStats() {
            return new HashMap<>(kills);
        }
        
        public int getTotalKills() {
            return kills.values().stream().mapToInt(Integer::intValue).sum();
        }
    }
}

package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import net.citizensnpcs.api.npc.NPCRegistry;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class NPCManager {
    
    private final WarriorNPCPlugin plugin;
    private final Map<String, NPCData> npcs = new ConcurrentHashMap<>();
    private final Map<String, NPC> citizenNPCs = new ConcurrentHashMap<>();
    private final File dataFile;
    private NPCRegistry registry;
    private boolean hasResumed = false;
    
    public NPCManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "npcs.yml");
        this.registry = CitizensAPI.getNPCRegistry();
        loadAll();
    }
    
    public NPCData createNPC(String name, Location location) {
        if (npcs.size() >= plugin.getConfigManager().getMaxNpcs()) {
            return null;
        }
        
        UUID uuid = UUID.randomUUID();
        NPCData data = new NPCData(uuid, name);
        data.setLocation(location);
        data.setSkinOwner(name);
        
        npcs.put(name, data);
        spawnNPC(data, location);
        
        return data;
    }
    
    public void spawnNPC(NPCData data, Location location) {
        NPC existingNPC = citizenNPCs.get(data.getName());
        if (existingNPC != null) {
            if (existingNPC.isSpawned()) {
                existingNPC.despawn();
            }
            existingNPC.destroy();
            citizenNPCs.remove(data.getName());
        }
        
        NPC npc = registry.createNPC(EntityType.PLAYER, data.getName());
        npc.spawn(location);
        
        npc.setName(data.getDisplayName());
        npc.setProtected(false);
        npc.data().setPersistent(NPC.Metadata.NAMEPLATE_VISIBLE, plugin.getConfigManager().isNameVisible());
        npc.data().setPersistent(NPC.Metadata.SHOULD_SAVE, false);
        
        npc.data().setPersistent("protected", false);
        npc.data().set("knockback", true);
        npc.setFlyable(false);
        
        npc.getNavigator().getDefaultParameters().baseSpeed(1.0f);
        npc.getNavigator().getDefaultParameters().avoidWater(true);
        npc.getNavigator().getDefaultParameters().range(50.0f);
        npc.getNavigator().getDefaultParameters().stationaryTicks(20);
        
        citizenNPCs.put(data.getName(), npc);
        
        if (npc.getEntity() instanceof Player player) {
            data.setNpcEntity(player);
            
            player.setGameMode(org.bukkit.GameMode.SURVIVAL);
            player.setGravity(true);
            player.setInvulnerable(false);
            player.setCollidable(true);
            player.setFlying(false);
            player.setAllowFlight(false);
            
            double health = Math.max(1.0, Math.min(data.getHealth(), 2048.0));
            player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).setBaseValue(health);
            player.setHealth(health);
            data.setHealth(health);
            
            org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                player.setGravity(true);
                player.setCollidable(true);
                player.setFlying(false);
                player.setAllowFlight(false);
                
                for (Map.Entry<String, ItemStack> entry : data.getEquipment().entrySet()) {
                    String slot = entry.getKey();
                    ItemStack item = entry.getValue();
                    switch (slot) {
                        case "hand" -> player.getInventory().setItemInMainHand(item);
                        case "offhand" -> player.getInventory().setItemInOffHand(item);
                        case "helmet" -> player.getInventory().setHelmet(item);
                        case "chest" -> player.getInventory().setChestplate(item);
                        case "legs" -> player.getInventory().setLeggings(item);
                        case "boots" -> player.getInventory().setBoots(item);
                    }
                }
                player.updateInventory();
            }, 10L);
        }
        
        if (data.getSkinOwner() != null) {
            npc.data().set("player-skin-name", data.getSkinOwner());
        }
    }
    
    public void removeNPC(String name) {
        NPCData data = npcs.remove(name);
        NPC npc = citizenNPCs.remove(name);
        
        if (npc != null) {
            npc.destroy();
        }
    }
    
    public void removeAll() {
        for (String name : new ArrayList<>(npcs.keySet())) {
            removeNPC(name);
        }
    }
    
    public NPCData getNPC(String name) {
        return npcs.get(name);
    }
    
    public Collection<NPCData> getAllNPCs() {
        return npcs.values();
    }
    
    public void refreshNPC(NPCData data) {
        NPC npc = citizenNPCs.get(data.getName());
        if (npc != null && data.getSkinOwner() != null) {
            npc.data().set("player-skin-name", data.getSkinOwner());
        }
    }
    
    public void saveAll() {
        FileConfiguration config = new YamlConfiguration();
        ConfigurationSection npcsSection = config.createSection("npcs");
        
        for (NPCData data : npcs.values()) {
            ConfigurationSection npcSection = npcsSection.createSection(data.getName());
            saveNPC(npcSection, data);
        }
        
        try {
            config.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().severe("Failed to save NPCs: " + e.getMessage());
        }
    }
    
    public boolean hasResumed() {
        return hasResumed;
    }
    
    public boolean resumeAll() {
        if (hasResumed) return false;
        hasResumed = true;
        
        for (NPCData data : npcs.values()) {
            Location loc = new Location(
                Bukkit.getWorld(data.getWorld()),
                data.getX(), data.getY(), data.getZ(),
                data.getYaw(), data.getPitch()
            );
            
            if (loc.getWorld() == null) continue;
            
            NPC npc = registry.createNPC(EntityType.PLAYER, data.getName());
            npc.spawn(loc);
            npc.setName(data.getDisplayName());
            npc.setProtected(false);
            npc.data().setPersistent(NPC.Metadata.NAMEPLATE_VISIBLE, plugin.getConfigManager().isNameVisible());
            npc.data().setPersistent(NPC.Metadata.SHOULD_SAVE, false);
            npc.data().setPersistent("protected", false);
            npc.data().set("knockback", true);
            npc.setFlyable(false);
            
            npc.getNavigator().getDefaultParameters().baseSpeed(1.0f);
            npc.getNavigator().getDefaultParameters().avoidWater(true);
            npc.getNavigator().getDefaultParameters().range(50.0f);
            npc.getNavigator().getDefaultParameters().stationaryTicks(20);
            
            citizenNPCs.put(data.getName(), npc);
            
            if (npc.getEntity() instanceof Player player) {
                data.setNpcEntity(player);
                player.setGameMode(org.bukkit.GameMode.SURVIVAL);
                player.setGravity(true);
                player.setInvulnerable(false);
                player.setCollidable(true);
                player.setFlying(false);
                player.setAllowFlight(false);
                
                double health = Math.max(1.0, Math.min(data.getHealth(), 2048.0));
                player.getAttribute(org.bukkit.attribute.Attribute.MAX_HEALTH).setBaseValue(health);
                player.setHealth(health);
                
                final String taskToResume = data.getCurrentTask();
                final boolean aiEnabled = data.isAiEnabled();
                
                org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    for (Map.Entry<String, ItemStack> entry : data.getEquipment().entrySet()) {
                        ItemStack item = entry.getValue();
                        if (item == null) continue;
                        
                        switch (entry.getKey()) {
                            case "hand" -> player.getInventory().setItemInMainHand(item);
                            case "offhand" -> player.getInventory().setItemInOffHand(item);
                            case "helmet" -> player.getInventory().setHelmet(item);
                            case "chest" -> player.getInventory().setChestplate(item);
                            case "legs" -> player.getInventory().setLeggings(item);
                            case "boots" -> player.getInventory().setBoots(item);
                        }
                    }
                    player.updateInventory();
                    
                    player.setGravity(true);
                    player.setCollidable(true);
                    player.setFlying(false);
                    player.setAllowFlight(false);
                    
                    if (aiEnabled) {
                        data.setAiEnabled(true);
                        
                        if ("GUARD".equals(taskToResume)) {
                            plugin.getGuardManager().startGuarding(data, loc, data.getGuardRadius());
                        } else if ("PATROL".equals(taskToResume) && !data.getPatrolWaypoints().isEmpty()) {
                            plugin.getPatrolManager().startPatrol(data);
                        } else if ("FOLLOW".equals(taskToResume) && data.getFollowTarget() != null) {
                            Player target = Bukkit.getPlayer(data.getFollowTarget());
                            if (target == null) {
                                NPCData targetNPC = getNPC(data.getFollowTarget());
                                if (targetNPC != null) target = targetNPC.getNpcEntity();
                            }
                            if (target != null) {
                                plugin.getMovementManager().followEntity(data, target);
                            }
                        }
                    }
                }, 20L);
            }
            
            if (data.getSkinOwner() != null) {
                npc.data().set("player-skin-name", data.getSkinOwner());
            }
        }
        
        return true;
    }
    
    private void saveNPC(ConfigurationSection section, NPCData data) {
        section.set("uuid", data.getUuid().toString());
        section.set("displayName", data.getDisplayName());
        section.set("skinOwner", data.getSkinOwner());
        section.set("world", data.getWorld());
        section.set("x", data.getX());
        section.set("y", data.getY());
        section.set("z", data.getZ());
        section.set("yaw", data.getYaw());
        section.set("pitch", data.getPitch());
        section.set("health", data.getHealth());
        section.set("currentTask", data.getCurrentTask());
        section.set("attackStyle", data.getAttackStyle().name());
        section.set("defenseStyle", data.getDefenseStyle().name());
        section.set("guardRadius", data.getGuardRadius());
        section.set("aiEnabled", data.isAiEnabled());
        section.set("followTarget", data.getFollowTarget());
        
        if (!data.getPatrolWaypoints().isEmpty()) {
            List<String> waypoints = new ArrayList<>();
            for (Location loc : data.getPatrolWaypoints()) {
                waypoints.add(loc.getWorld().getName() + "," + 
                    loc.getX() + "," + loc.getY() + "," + loc.getZ());
            }
            section.set("patrolWaypoints", waypoints);
        }
        
        if (!data.getEquipment().isEmpty()) {
            ConfigurationSection equipSection = section.createSection("equipment");
            for (Map.Entry<String, ItemStack> entry : data.getEquipment().entrySet()) {
                equipSection.set(entry.getKey(), entry.getValue());
            }
        }
    }
    
    private void loadAll() {
        if (!dataFile.exists()) {
            plugin.saveResource("npcs.yml", false);
            return;
        }
        
        FileConfiguration config = YamlConfiguration.loadConfiguration(dataFile);
        ConfigurationSection npcsSection = config.getConfigurationSection("npcs");
        
        if (npcsSection == null) return;
        
        for (String name : npcsSection.getKeys(false)) {
            ConfigurationSection npcSection = npcsSection.getConfigurationSection(name);
            NPCData data = loadNPC(name, npcSection);
            if (data != null) {
                npcs.put(name, data);
                // Don't spawn NPCs on load - only load data
                // NPCs will be spawned when resumeAll() is called
            }
        }
    }
    
    private NPCData loadNPC(String name, ConfigurationSection section) {
        UUID uuid = UUID.fromString(section.getString("uuid"));
        NPCData data = new NPCData(uuid, name);
        
        data.setDisplayName(section.getString("displayName", name));
        data.setSkinOwner(section.getString("skinOwner"));
        data.setWorld(section.getString("world"));
        data.setX(section.getDouble("x"));
        data.setY(section.getDouble("y"));
        data.setZ(section.getDouble("z"));
        data.setYaw((float) section.getDouble("yaw"));
        data.setPitch((float) section.getDouble("pitch"));
        data.setHealth(section.getDouble("health"));
        data.setCurrentTask(section.getString("currentTask", "IDLE"));
        data.setGuardRadius(section.getDouble("guardRadius", 10.0));
        data.setAiEnabled(section.getBoolean("aiEnabled", true));
        data.setFollowTarget(section.getString("followTarget"));
        
        List<String> waypoints = section.getStringList("patrolWaypoints");
        if (waypoints != null) {
            for (String wp : waypoints) {
                String[] parts = wp.split(",");
                if (parts.length == 4) {
                    org.bukkit.World world = Bukkit.getWorld(parts[0]);
                    if (world != null) {
                        Location loc = new Location(world, 
                            Double.parseDouble(parts[1]),
                            Double.parseDouble(parts[2]),
                            Double.parseDouble(parts[3]));
                        data.getPatrolWaypoints().add(loc);
                    }
                }
            }
        }
        
        String attackStyle = section.getString("attackStyle", "LT3");
        String defenseStyle = section.getString("defenseStyle", "LT3");
        
        try {
            data.setAttackStyle(com.spacygaming.warriornpc.combat.FightStyle.valueOf(attackStyle));
            data.setDefenseStyle(com.spacygaming.warriornpc.combat.FightStyle.valueOf(defenseStyle));
        } catch (Exception ignored) {}
        
        ConfigurationSection equipSection = section.getConfigurationSection("equipment");
        if (equipSection != null) {
            for (String slot : equipSection.getKeys(false)) {
                ItemStack item = equipSection.getItemStack(slot);
                if (item != null) {
                    data.getEquipment().put(slot, item);
                }
            }
        }
        
        return data;
    }
}

package com.spacygaming.warriornpc.managers;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.SkinData;
import org.bukkit.Bukkit;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

public class SkinManager {
    
    private final WarriorNPCPlugin plugin;
    private final Map<String, SkinData> skinCache = new ConcurrentHashMap<>();
    
    public SkinManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public CompletableFuture<SkinData> loadSkin(String username) {
        if (skinCache.containsKey(username)) {
            SkinData cached = skinCache.get(username);
            if (!cached.isExpired(plugin.getConfigManager().getSkinCacheDuration())) {
                return CompletableFuture.completedFuture(cached);
            }
        }
        
        return CompletableFuture.supplyAsync(() -> {
            try {
                String uuid = getUUID(username);
                if (uuid == null) return null;
                
                SkinData skinData = fetchSkin(uuid);
                if (skinData != null && plugin.getConfigManager().isSkinCacheEnabled()) {
                    skinCache.put(username, skinData);
                }
                return skinData;
            } catch (Exception e) {
                plugin.getLogger().warning("Failed to load skin for " + username + ": " + e.getMessage());
                return null;
            }
        });
    }
    
    private String getUUID(String username) throws Exception {
        String urlString = plugin.getConfigManager().getMojangApiUrl() + "/users/profiles/minecraft/" + username;
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);
        
        if (conn.getResponseCode() != 200) {
            return null;
        }
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        
        JsonObject json = JsonParser.parseString(response.toString()).getAsJsonObject();
        return json.get("id").getAsString();
    }
    
    private SkinData fetchSkin(String uuid) throws Exception {
        String urlString = plugin.getConfigManager().getSessionServerUrl() + "/session/minecraft/profile/" + uuid + "?unsigned=false";
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        conn.setConnectTimeout(5000);
        conn.setReadTimeout(5000);
        
        if (conn.getResponseCode() != 200) {
            return null;
        }
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }
        reader.close();
        
        JsonObject json = JsonParser.parseString(response.toString()).getAsJsonObject();
        JsonObject properties = json.getAsJsonArray("properties").get(0).getAsJsonObject();
        
        String texture = properties.get("value").getAsString();
        String signature = properties.get("signature").getAsString();
        
        return new SkinData(texture, signature);
    }
    
    public void clearCache() {
        skinCache.clear();
    }
}

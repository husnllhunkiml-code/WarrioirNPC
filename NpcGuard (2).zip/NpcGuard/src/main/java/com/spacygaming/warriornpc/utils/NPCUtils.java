package com.spacygaming.warriornpc.utils;

import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.util.Vector;

public class NPCUtils {
    
    public static boolean hasLineOfSight(Location from, Location to) {
        if (from.getWorld() != to.getWorld()) return false;
        
        Vector direction = to.toVector().subtract(from.toVector());
        double distance = direction.length();
        direction.normalize();
        
        Location current = from.clone();
        double step = 0.5;
        
        for (double i = 0; i < distance; i += step) {
            current.add(direction.clone().multiply(step));
            if (current.getBlock().getType().isSolid()) {
                return false;
            }
        }
        
        return true;
    }
    
    public static float calculateYaw(Vector direction) {
        double x = direction.getX();
        double z = direction.getZ();
        double angle = Math.atan2(-x, z);
        return (float) Math.toDegrees(angle);
    }
    
    public static float calculatePitch(Vector direction) {
        double x = direction.getX();
        double y = direction.getY();
        double z = direction.getZ();
        
        double xz = Math.sqrt(x * x + z * z);
        double angle = Math.atan2(-y, xz);
        return (float) Math.toDegrees(angle);
    }
    
    public static Vector getDirection(Location from, Location to) {
        return to.toVector().subtract(from.toVector()).normalize();
    }
    
    public static double getDistance2D(Location from, Location to) {
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        return Math.sqrt(dx * dx + dz * dz);
    }
    
    public static boolean isInRange(Entity entity, Entity target, double range) {
        return entity.getLocation().distance(target.getLocation()) <= range;
    }
}

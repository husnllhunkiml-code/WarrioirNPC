package com.spacygaming.warriornpc.models;

import com.spacygaming.warriornpc.combat.FightStyle;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class NPCData {
    
    private final UUID uuid;
    private String name;
    private String displayName;
    private String skinOwner;
    private String world;
    private double x, y, z;
    private float yaw, pitch;
    private double health;
    private Map<String, ItemStack> equipment;
    private String currentTask;
    private FightStyle attackStyle;
    private FightStyle defenseStyle;
    private List<Location> patrolWaypoints;
    private String followTarget;
    private double guardRadius;
    private boolean aiEnabled;
    
    private transient Player npcEntity;
    
    public NPCData(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
        this.displayName = name;
        this.health = 20.0;
        this.equipment = new HashMap<>();
        this.currentTask = "IDLE";
        this.attackStyle = FightStyle.LT3;
        this.defenseStyle = FightStyle.LT3;
        this.patrolWaypoints = new ArrayList<>();
        this.guardRadius = 10.0;
        this.aiEnabled = true;
    }
    
    public UUID getUuid() { return uuid; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public String getSkinOwner() { return skinOwner; }
    public void setSkinOwner(String skinOwner) { this.skinOwner = skinOwner; }
    public String getWorld() { return world; }
    public void setWorld(String world) { this.world = world; }
    public double getX() { return x; }
    public void setX(double x) { this.x = x; }
    public double getY() { return y; }
    public void setY(double y) { this.y = y; }
    public double getZ() { return z; }
    public void setZ(double z) { this.z = z; }
    public float getYaw() { return yaw; }
    public void setYaw(float yaw) { this.yaw = yaw; }
    public float getPitch() { return pitch; }
    public void setPitch(float pitch) { this.pitch = pitch; }
    public double getHealth() { return health; }
    public void setHealth(double health) { this.health = health; }
    public Map<String, ItemStack> getEquipment() { return equipment; }
    public void setEquipment(Map<String, ItemStack> equipment) { this.equipment = equipment; }
    public String getCurrentTask() { return currentTask; }
    public void setCurrentTask(String currentTask) { this.currentTask = currentTask; }
    public FightStyle getAttackStyle() { return attackStyle; }
    public void setAttackStyle(FightStyle attackStyle) { this.attackStyle = attackStyle; }
    public FightStyle getDefenseStyle() { return defenseStyle; }
    public void setDefenseStyle(FightStyle defenseStyle) { this.defenseStyle = defenseStyle; }
    public List<Location> getPatrolWaypoints() { return patrolWaypoints; }
    public void setPatrolWaypoints(List<Location> patrolWaypoints) { this.patrolWaypoints = patrolWaypoints; }
    public String getFollowTarget() { return followTarget; }
    public void setFollowTarget(String followTarget) { this.followTarget = followTarget; }
    public double getGuardRadius() { return guardRadius; }
    public void setGuardRadius(double guardRadius) { this.guardRadius = guardRadius; }
    public boolean isAiEnabled() { return aiEnabled; }
    public void setAiEnabled(boolean aiEnabled) { this.aiEnabled = aiEnabled; }
    public Player getNpcEntity() { return npcEntity; }
    public void setNpcEntity(Player npcEntity) { this.npcEntity = npcEntity; }
    
    public Location getLocation() {
        return npcEntity != null ? npcEntity.getLocation() : null;
    }
    
    public void setLocation(Location loc) {
        if (loc != null) {
            this.world = loc.getWorld().getName();
            this.x = loc.getX();
            this.y = loc.getY();
            this.z = loc.getZ();
            this.yaw = loc.getYaw();
            this.pitch = loc.getPitch();
        }
    }
}

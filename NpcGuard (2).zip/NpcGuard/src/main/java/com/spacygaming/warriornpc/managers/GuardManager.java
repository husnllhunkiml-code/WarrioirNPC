package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import org.bukkit.Location;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class GuardManager {
    
    private final WarriorNPCPlugin plugin;
    private final Map<String, Location> guardCenters = new ConcurrentHashMap<>();
    private final Map<String, Double> guardRadii = new ConcurrentHashMap<>();
    private final Map<String, Double> patrolAngles = new ConcurrentHashMap<>();
    private final Map<String, Integer> patrolTicks = new ConcurrentHashMap<>();
    private final Map<String, Monster> combatTargets = new ConcurrentHashMap<>();
    
    public GuardManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void startGuarding(NPCData data, Location center, double radius) {
        String name = data.getName();
        guardCenters.put(name, center.clone());
        guardRadii.put(name, radius);
        patrolAngles.put(name, 0.0);
        patrolTicks.put(name, 0);
        combatTargets.remove(name);
        data.setGuardRadius(radius);
        data.setCurrentTask("GUARD");
    }
    
    public void stopGuarding(NPCData data) {
        String name = data.getName();
        guardCenters.remove(name);
        guardRadii.remove(name);
        patrolAngles.remove(name);
        patrolTicks.remove(name);
        combatTargets.remove(name);
        plugin.getMovementManager().stopMovement(data);
    }
    
    public void tick(NPCData data) {
        if (!"GUARD".equals(data.getCurrentTask())) return;
        if (data.getNpcEntity() == null || !data.isAiEnabled()) return;
        
        String name = data.getName();
        Player npc = data.getNpcEntity();
        
        npc.setGravity(true);
        npc.setFlying(false);
        npc.setAllowFlight(false);
        npc.setCollidable(true);
        npc.setInvulnerable(false);
        
        Location center = guardCenters.get(name);
        if (center == null) return;
        
        double radius = guardRadii.getOrDefault(name, 10.0);
        Location npcLoc = npc.getLocation();
        
        Monster targetMob = combatTargets.get(name);
        
        if (targetMob != null && (targetMob.isDead() || !targetMob.isValid())) {
            combatTargets.remove(name);
            targetMob = null;
        }
        
        if (targetMob == null) {
            List<Monster> nearbyMobs = center.getWorld().getNearbyEntities(center, radius, radius, radius).stream()
                .filter(e -> e instanceof Monster)
                .filter(e -> e.isValid() && !((Monster)e).isDead())
                .map(e -> (Monster)e)
                .sorted((a, b) -> Double.compare(
                    npcLoc.distance(a.getLocation()),
                    npcLoc.distance(b.getLocation())
                ))
                .toList();
            
            if (!nearbyMobs.isEmpty()) {
                targetMob = nearbyMobs.get(0);
                combatTargets.put(name, targetMob);
            }
        }
        
        if (targetMob != null) {
            Location mobLoc = targetMob.getLocation();
            double distanceToMob = npcLoc.distance(mobLoc);
            
            if (center.distance(mobLoc) > radius + 5) {
                combatTargets.remove(name);
                return;
            }
            
            plugin.getMovementManager().lookAt(data, targetMob);
            
            if (distanceToMob > 3.5) {
                npc.setSprinting(true);
                plugin.getMovementManager().walkTo(data, targetMob);
            } else {
                plugin.getMovementManager().stopMovement(data);
                npc.setSprinting(false);
                
                final Monster finalMob = targetMob;
                npc.attack(finalMob);
                npc.swingMainHand();
                
                org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    if (finalMob.isValid() && !finalMob.isDead()) {
                        org.bukkit.util.Vector direction = finalMob.getLocation().toVector()
                            .subtract(npc.getLocation().toVector())
                            .normalize()
                            .multiply(0.5)
                            .setY(0.25);
                        finalMob.setVelocity(direction);
                    }
                }, 1L);
                
                npc.getWorld().playSound(npcLoc, 
                    org.bukkit.Sound.ENTITY_PLAYER_ATTACK_STRONG, 1.0f, 1.0f);
            }
            return;
        }
        
        int ticks = patrolTicks.getOrDefault(name, 0);
        patrolTicks.put(name, ticks + 1);
        
        if (ticks % 30 == 0) {
            double angle = patrolAngles.getOrDefault(name, 0.0);
            angle += Math.PI / 6;
            if (angle >= 2 * Math.PI) {
                angle = 0.0;
            }
            patrolAngles.put(name, angle);
            
            double patrolRadius = radius * 0.65;
            double x = center.getX() + Math.cos(angle) * patrolRadius;
            double z = center.getZ() + Math.sin(angle) * patrolRadius;
            double y = center.getWorld().getHighestBlockYAt((int)x, (int)z) + 1;
            
            Location patrolPoint = new Location(center.getWorld(), x, y, z);
            plugin.getMovementManager().walkTo(data, patrolPoint);
        }
        
        if (npcLoc.distance(center) > radius + 3) {
            plugin.getMovementManager().walkTo(data, center);
        }
    }
    
    public boolean isGuarding(NPCData data) {
        return guardCenters.containsKey(data.getName());
    }
}

package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.*;

public class PathfindingManager {
    
    private final WarriorNPCPlugin plugin;
    private final Map<String, Location> targetLocations = new HashMap<>();
    private final Map<String, Integer> pathTicks = new HashMap<>();
    
    public PathfindingManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void navigateTo(NPCData data, Location target) {
        targetLocations.put(data.getName(), target);
        pathTicks.put(data.getName(), 0);
    }
    
    public void stopNavigation(NPCData data) {
        targetLocations.remove(data.getName());
        pathTicks.remove(data.getName());
    }
    
    public void tick(NPCData data) {
        if (data.getNpcEntity() == null) return;
        
        Location target = targetLocations.get(data.getName());
        if (target == null) return;
        
        Location current = data.getLocation();
        if (current.getWorld() != target.getWorld()) {
            stopNavigation(data);
            return;
        }
        
        double distance = current.distance(target);
        if (distance < 0.5) {
            stopNavigation(data);
            return;
        }
        
        int ticks = pathTicks.getOrDefault(data.getName(), 0);
        if (ticks % plugin.getConfigManager().getRecalculateTicks() == 0) {
            moveTowards(data, target);
        }
        pathTicks.put(data.getName(), ticks + 1);
    }
    
    private void moveTowards(NPCData data, Location target) {
        Player npc = data.getNpcEntity();
        Location current = npc.getLocation();
        
        Vector direction = target.toVector().subtract(current.toVector()).normalize();
        Location next = current.clone().add(direction.multiply(0.3));
        
        if (isPathBlocked(current, next)) {
            next = findAlternativePath(current, target);
            if (next == null) return;
        }
        
        float yaw = getYaw(direction);
        next.setYaw(yaw);
        next.setPitch(current.getPitch());
        
        npc.teleport(next);
        data.setLocation(next);
    }
    
    private boolean isPathBlocked(Location from, Location to) {
        Block block = to.getBlock();
        Material type = block.getType();
        
        if (type.isSolid() && type != Material.SHORT_GRASS && type != Material.TALL_GRASS) {
            return true;
        }
        
        if (plugin.getConfigManager().isAvoidWater() && type == Material.WATER) {
            return true;
        }
        
        Block below = to.clone().subtract(0, 1, 0).getBlock();
        if (below.getType() == Material.AIR || below.getType() == Material.LAVA) {
            return true;
        }
        
        return false;
    }
    
    private Location findAlternativePath(Location current, Location target) {
        Vector direction = target.toVector().subtract(current.toVector()).normalize();
        
        Vector[] offsets = {
            direction.clone().rotateAroundY(Math.toRadians(45)),
            direction.clone().rotateAroundY(Math.toRadians(-45)),
            direction.clone().rotateAroundY(Math.toRadians(90)),
            direction.clone().rotateAroundY(Math.toRadians(-90))
        };
        
        for (Vector offset : offsets) {
            Location test = current.clone().add(offset.multiply(0.3));
            if (!isPathBlocked(current, test)) {
                return test;
            }
        }
        
        return null;
    }
    
    private float getYaw(Vector direction) {
        double x = direction.getX();
        double z = direction.getZ();
        double angle = Math.atan2(-x, z);
        return (float) Math.toDegrees(angle);
    }
    
    public boolean hasTarget(NPCData data) {
        return targetLocations.containsKey(data.getName());
    }
    
    public Location getTarget(NPCData data) {
        return targetLocations.get(data.getName());
    }
}

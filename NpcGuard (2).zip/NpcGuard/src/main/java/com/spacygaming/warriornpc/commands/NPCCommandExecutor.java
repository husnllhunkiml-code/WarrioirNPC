package com.spacygaming.warriornpc.commands;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.combat.FightStyle;
import com.spacygaming.warriornpc.models.NPCData;
import com.spacygaming.warriornpc.managers.TeamManager;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class NPCCommandExecutor implements CommandExecutor {
    
    private final WarriorNPCPlugin plugin;
    
    public NPCCommandExecutor(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    private void clearAllStates(NPCData data) {
        // Stop AI first
        data.setAiEnabled(false);
        
        // Clear all managers
        plugin.getCombatManager().clearTargets(data);
        plugin.getMovementManager().stopMovement(data);
        plugin.getPatrolManager().stopPatrol(data);
        plugin.getGuardManager().stopGuarding(data);
        
        // Clear data states
        data.setFollowTarget(null);
        data.setCurrentTask("IDLE");
        
        // Force gravity
        if (data.getNpcEntity() != null) {
            data.getNpcEntity().setGravity(true);
            data.getNpcEntity().setFlying(false);
            data.getNpcEntity().setAllowFlight(false);
        }
    }
    
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("warriornpc.use")) {
            plugin.getMessageManager().send(sender, "no-permission");
            return true;
        }
        
        if (args.length == 0) {
            plugin.getMessageManager().send(sender, "invalid-command");
            return true;
        }
        
        String subCmd = args[0].toLowerCase();
        
        switch (subCmd) {
            case "spawn" -> handleSpawn(sender, args);
            case "remove" -> handleRemove(sender, args);
            case "list" -> handleList(sender);
            case "info" -> handleInfo(sender, args);
            case "tp" -> handleTp(sender, args);
            case "tphere" -> handleTpHere(sender, args);
            case "goto" -> handleGoto(sender, args);
            case "follow" -> handleFollow(sender, args);
            case "attack" -> handleAttack(sender, args);
            case "duel" -> handleDuel(sender, args);
            case "fight" -> handleFight(sender, args);
            case "guard" -> handleGuard(sender, args);
            case "patrol" -> handlePatrol(sender, args);
            case "build" -> handleBuild(sender, args);
            case "style" -> handleStyle(sender, args);
            case "wear" -> handleWear(sender, args);
            case "clearwear" -> handleClearWear(sender, args);
            case "start" -> handleStart(sender, args);
            case "stop" -> handleStop(sender, args);
            case "rename" -> handleRename(sender, args);
            case "reloadskin" -> handleReloadSkin(sender, args);
            case "reset" -> handleReset(sender, args);
            case "reload" -> handleReload(sender);
            case "resumeallnpc" -> handleResumeAll(sender);
            case "health" -> new NPCHealthCommand(plugin).handleSetHealth(sender, args);
            case "inventory", "inv" -> handleInventory(sender, args);
            case "team" -> handleTeam(sender, args);
            default -> plugin.getMessageManager().send(sender, "invalid-command");
        }
        
        return true;
    }
    
    private void handleSpawn(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (args.length < 2) {
            sender.sendMessage("Usage: /wnpc spawn <name>");
            return;
        }
        
        String name = args[1];
        if (plugin.getNpcManager().getNPC(name) != null) {
            sender.sendMessage("§cNPC with that name already exists!");
            return;
        }
        
        NPCData data = plugin.getNpcManager().createNPC(name, player.getLocation());
        if (data == null) {
            plugin.getMessageManager().send(sender, "spawn-limit");
            return;
        }
        
        org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (data.getNpcEntity() != null) {
                data.getNpcEntity().setGravity(true);
                data.getNpcEntity().setFlying(false);
                data.getNpcEntity().setAllowFlight(false);
            }
            plugin.getNpcManager().saveAll();
        }, 5L);
        
        plugin.getEffectsManager().playSpawnEffect(player.getLocation(), name);
        
        sender.sendMessage("§aSpawned NPC §e" + name + "§a!");
    }
    
    private void handleRemove(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("Usage: /wnpc remove <npc>");
            return;
        }
        
        String name = args[1];
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        Location loc = data.getLocation();
        plugin.getNpcManager().removeNPC(name);
        
        // Play remove effects
        if (loc != null) {
            plugin.getEffectsManager().playRemoveEffect(loc, name);
        }
        
        plugin.getMessageManager().send(sender, "remove-success", "name", name);
    }
    
    private void handleList(CommandSender sender) {
        Collection<NPCData> npcs = plugin.getNpcManager().getAllNPCs();
        
        Map<String, String> replacements = new HashMap<>();
        replacements.put("count", String.valueOf(npcs.size()));
        plugin.getMessageManager().send(sender, "list-header", replacements);
        
        for (NPCData data : npcs) {
            Map<String, String> entryMap = new HashMap<>();
            entryMap.put("name", data.getName());
            entryMap.put("id", data.getUuid().toString().substring(0, 8));
            entryMap.put("world", data.getWorld());
            plugin.getMessageManager().send(sender, "list-entry", entryMap);
        }
    }
    
    private void handleInfo(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("Usage: /wnpc info <npc>");
            return;
        }
        
        String name = args[1];
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        Map<String, String> infoMap = new HashMap<>();
        infoMap.put("name", data.getName());
        plugin.getMessageManager().send(sender, "info-header", infoMap);
        
        Map<String, String> locMap = new HashMap<>();
        locMap.put("world", data.getWorld());
        locMap.put("x", String.format("%.1f", data.getX()));
        locMap.put("y", String.format("%.1f", data.getY()));
        locMap.put("z", String.format("%.1f", data.getZ()));
        plugin.getMessageManager().send(sender, "info-location", locMap);
        
        Map<String, String> healthMap = new HashMap<>();
        healthMap.put("health", String.format("%.1f", data.getHealth()));
        plugin.getMessageManager().send(sender, "info-health", healthMap);
        
        Map<String, String> taskMap = new HashMap<>();
        taskMap.put("task", data.getCurrentTask());
        plugin.getMessageManager().send(sender, "info-task", taskMap);
        
        Map<String, String> styleMap = new HashMap<>();
        styleMap.put("attack", data.getAttackStyle().name());
        styleMap.put("defense", data.getDefenseStyle().name());
        plugin.getMessageManager().send(sender, "info-style", styleMap);
    }
    
    private void handleTp(CommandSender sender, String[] args) {
        if (args.length < 5) {
            sender.sendMessage("Usage: /wnpc tp <npc> <x> <y> <z>");
            return;
        }
        
        String name = args[1];
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        try {
            double x = Double.parseDouble(args[2]);
            double y = Double.parseDouble(args[3]);
            double z = Double.parseDouble(args[4]);
            
            Location from = data.getLocation();
            Location to = new Location(data.getNpcEntity().getWorld(), x, y, z);
            
            data.getNpcEntity().teleport(to);
            data.getNpcEntity().setGravity(true);
            data.setLocation(to);
            
            plugin.getEffectsManager().playTeleportEffect(from, to);
            
            sender.sendMessage("§aTeleported §e" + name + "§a to §e" + String.format("%.1f, %.1f, %.1f", x, y, z));
        } catch (NumberFormatException e) {
            sender.sendMessage("Invalid coordinates!");
        }
    }
    
    private void handleTpHere(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (args.length < 2) {
            sender.sendMessage("Usage: /wnpc tphere <npc|all>");
            return;
        }
        
        String name = args[1];
        
        if (name.equalsIgnoreCase("all")) {
            Collection<NPCData> allNPCs = plugin.getNpcManager().getAllNPCs();
            if (allNPCs.isEmpty()) {
                sender.sendMessage("§cNo NPCs to teleport!");
                return;
            }
            
            Location to = player.getLocation();
            int count = 0;
            
            for (NPCData data : allNPCs) {
                if (data.getNpcEntity() == null || !data.getNpcEntity().isValid()) {
                    plugin.getNpcManager().spawnNPC(data, to);
                    data.setLocation(to);
                    count++;
                } else {
                    data.getNpcEntity().teleport(to);
                    data.getNpcEntity().setGravity(true);
                    data.setLocation(to);
                    count++;
                }
            }
            
            plugin.getEffectsManager().playTeleportEffect(to, to);
            sender.sendMessage("§a✓ Teleported §e" + count + "§a NPCs to you!");
            return;
        }
        
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        Location to = player.getLocation();
        
        if (data.getNpcEntity() == null || !data.getNpcEntity().isValid()) {
            plugin.getNpcManager().spawnNPC(data, to);
            data.setLocation(to);
            plugin.getEffectsManager().playSpawnEffect(to, name);
            sender.sendMessage("§aRespawned and teleported §e" + name + " §ato you!");
        } else {
            Location from = data.getLocation();
            data.getNpcEntity().teleport(to);
            data.getNpcEntity().setGravity(true);
            data.setLocation(to);
            plugin.getEffectsManager().playTeleportEffect(from, to);
            sender.sendMessage("§aTeleported §e" + name + " §ato you!");
        }
    }
    
    private void handleGoto(CommandSender sender, String[] args) {
        if (args.length < 5) {
            sender.sendMessage("Usage: /wnpc goto <npc> <x> <y> <z>");
            return;
        }
        
        String name = args[1];
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        try {
            double x = Double.parseDouble(args[2]);
            double y = Double.parseDouble(args[3]);
            double z = Double.parseDouble(args[4]);
            
            Location loc = new Location(data.getNpcEntity().getWorld(), x, y, z);
            plugin.getMovementManager().walkTo(data, loc);
            data.setCurrentTask("GOTO");
            
            Map<String, String> gotoMap = new HashMap<>();
            gotoMap.put("npc", name);
            gotoMap.put("x", String.format("%.1f", x));
            gotoMap.put("y", String.format("%.1f", y));
            gotoMap.put("z", String.format("%.1f", z));
            plugin.getMessageManager().send(sender, "goto-success", gotoMap);
        } catch (NumberFormatException e) {
            sender.sendMessage("Invalid coordinates!");
        }
    }
    
    private void handleFollow(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /wnpc follow <npc> <target>");
            return;
        }
        
        String name = args[1];
        String targetName = args[2];
        
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        Player targetPlayer = Bukkit.getPlayer(targetName);
        if (targetPlayer == null) {
            NPCData targetNPC = plugin.getNpcManager().getNPC(targetName);
            if (targetNPC != null && targetNPC.getNpcEntity() != null) {
                targetPlayer = targetNPC.getNpcEntity();
            }
        }
        
        if (targetPlayer == null) {
            sender.sendMessage("§cTarget not found!");
            return;
        }
        
        final Player finalTarget = targetPlayer;
        final String finalTargetName = targetName;
        
        // Stop other tasks but don't disable AI
        plugin.getCombatManager().clearTargets(data);
        plugin.getMovementManager().stopMovement(data);
        plugin.getPatrolManager().stopPatrol(data);
        plugin.getGuardManager().stopGuarding(data);
        
        // Immediately start following without delay
        data.setFollowTarget(finalTargetName);
        data.setCurrentTask("FOLLOW");
        data.setAiEnabled(true);
        
        // Force gravity
        if (data.getNpcEntity() != null) {
            data.getNpcEntity().setGravity(true);
            data.getNpcEntity().setFlying(false);
            data.getNpcEntity().setAllowFlight(false);
        }
        
        plugin.getMovementManager().followEntity(data, finalTarget);
        plugin.getNpcManager().saveAll();
        
        sender.sendMessage("§a" + name + " is now following §e" + targetName);
    }
    
    private void handleAttack(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("§cUsage: /wnpc attack <npc> <target>");
            return;
        }
        
        String name = args[1];
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        if (data.getNpcEntity() == null || !data.getNpcEntity().isValid()) {
            sender.sendMessage("§cNPC is not spawned!");
            return;
        }
        
        String targetName = args[2];
        Player target = org.bukkit.Bukkit.getPlayer(targetName);
        
        if (target == null) {
            sender.sendMessage("§cPlayer '" + targetName + "' not found!");
            return;
        }
        
        if (!target.isOnline()) {
            sender.sendMessage("§cPlayer '" + targetName + "' is not online!");
            return;
        }
        
        if (!data.getNpcEntity().getWorld().equals(target.getWorld())) {
            sender.sendMessage("§cNPC and target are in different worlds!");
            return;
        }
        
        clearAllStates(data);
        
        Player npc = data.getNpcEntity();
        npc.setGravity(true);
        npc.setCollidable(true);
        npc.setInvulnerable(false);
        npc.setFlying(false);
        npc.setAllowFlight(false);
        
        org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
            List<LivingEntity> targets = new ArrayList<>();
            targets.add(target);
            
            plugin.getCombatManager().setTargets(data, targets);
            data.setCurrentTask("COMBAT");
            data.setAiEnabled(true);
            
            plugin.getEffectsManager().playCombatStartEffect(data.getNpcEntity().getLocation());
            plugin.getNpcManager().saveAll();
        }, 5L);
        
        sender.sendMessage("§a" + name + " is now hunting §e" + targetName + "§a!");
    }
    
    private void handleDuel(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /wnpc duel <npc1> <npc2>");
            return;
        }
        
        String name1 = args[1];
        String name2 = args[2];
        
        NPCData npc1 = plugin.getNpcManager().getNPC(name1);
        NPCData npc2 = plugin.getNpcManager().getNPC(name2);
        
        if (npc1 == null || npc2 == null) {
            sender.sendMessage("§cOne or both NPCs not found!");
            return;
        }
        
        if (npc1.getNpcEntity() == null || npc2.getNpcEntity() == null) {
            sender.sendMessage("§cOne or both NPCs are not spawned!");
            return;
        }
        
        if (!npc1.getNpcEntity().getWorld().equals(npc2.getNpcEntity().getWorld())) {
            sender.sendMessage("§cNPCs must be in the same world!");
            return;
        }
        
        clearAllStates(npc1);
        clearAllStates(npc2);
        
        Player p1 = npc1.getNpcEntity();
        Player p2 = npc2.getNpcEntity();
        
        p1.setGravity(true);
        p1.setCollidable(true);
        p1.setInvulnerable(false);
        p1.setFlying(false);
        p1.setAllowFlight(false);
        
        p2.setGravity(true);
        p2.setCollidable(true);
        p2.setInvulnerable(false);
        p2.setFlying(false);
        p2.setAllowFlight(false);
        
        sender.sendMessage("§e§l⚔ DUEL STARTING ⚔");
        sender.sendMessage("§a" + name1 + " §7vs §c" + name2);
        sender.sendMessage("§7Duel begins in 3 seconds...");
        
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            sender.sendMessage("§e3...");
        }, 20L);
        
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            sender.sendMessage("§e2...");
        }, 40L);
        
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            sender.sendMessage("§e1...");
        }, 60L);
        
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            sender.sendMessage("§c§lFIGHT!");
            
            npc1.setAiEnabled(true);
            npc2.setAiEnabled(true);
            npc1.setCurrentTask("DUEL");
            npc2.setCurrentTask("DUEL");
            
            List<LivingEntity> targets1 = new ArrayList<>();
            targets1.add(npc2.getNpcEntity());
            plugin.getCombatManager().setTargets(npc1, targets1);
            
            List<LivingEntity> targets2 = new ArrayList<>();
            targets2.add(npc1.getNpcEntity());
            plugin.getCombatManager().setTargets(npc2, targets2);
            
            plugin.getEffectsManager().playCombatStartEffect(npc1.getNpcEntity().getLocation());
            plugin.getEffectsManager().playCombatStartEffect(npc2.getNpcEntity().getLocation());
            
            npc1.getLocation().getWorld().playSound(
                npc1.getLocation(), 
                org.bukkit.Sound.ENTITY_ENDER_DRAGON_GROWL, 
                1.0f, 
                2.0f
            );
            
            startDuelMonitor(npc1, npc2, sender);
        }, 80L);
    }
    
    private void startDuelMonitor(NPCData npc1, NPCData npc2, CommandSender sender) {
        final int[] taskId = new int[1];
        
        taskId[0] = Bukkit.getScheduler().scheduleSyncRepeatingTask(plugin, () -> {
            Player p1 = npc1.getNpcEntity();
            Player p2 = npc2.getNpcEntity();
            
            if (p1 == null || p2 == null || p1.isDead() || p2.isDead() || 
                !p1.isValid() || !p2.isValid()) {
                
                Bukkit.getScheduler().cancelTask(taskId[0]);
                
                String winner = null;
                String loser = null;
                
                if (p1 != null && p1.isValid() && !p1.isDead()) {
                    winner = npc1.getName();
                    loser = npc2.getName();
                    plugin.getCombatManager().clearTargets(npc1);
                    npc1.setCurrentTask("IDLE");
                } else if (p2 != null && p2.isValid() && !p2.isDead()) {
                    winner = npc2.getName();
                    loser = npc1.getName();
                    plugin.getCombatManager().clearTargets(npc2);
                    npc2.setCurrentTask("IDLE");
                } else {
                    sender.sendMessage("§e§l⚔ DUEL ENDED ⚔");
                    sender.sendMessage("§7Both fighters eliminated!");
                    plugin.getCombatManager().clearTargets(npc1);
                    plugin.getCombatManager().clearTargets(npc2);
                    npc1.setCurrentTask("IDLE");
                    npc2.setCurrentTask("IDLE");
                    return;
                }
                
                sender.sendMessage("§e§l⚔ DUEL ENDED ⚔");
                sender.sendMessage("§a§l✓ WINNER: §e" + winner);
                sender.sendMessage("§c§l✗ ELIMINATED: §7" + loser);
                
                if (winner.equals(npc1.getName()) && p1 != null) {
                    plugin.getEffectsManager().playVictoryEffect(p1.getLocation());
                    p1.getWorld().playSound(p1.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                } else if (winner.equals(npc2.getName()) && p2 != null) {
                    plugin.getEffectsManager().playVictoryEffect(p2.getLocation());
                    p2.getWorld().playSound(p2.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 1.0f);
                }
            }
        }, 20L, 20L);
    }
    
    private void handleFight(CommandSender sender, String[] args) {
        if (args.length < 4 || !args[2].equalsIgnoreCase("vs")) {
            sender.sendMessage("Usage: /wnpc fight team:npc1,npc2 vs team:npc3,npc4");
            return;
        }
        
        String team1Str = args[1];
        String team2Str = args[3];
        
        if (!team1Str.startsWith("team:") || !team2Str.startsWith("team:")) {
            sender.sendMessage("Format: team:npc1,npc2");
            return;
        }
        
        String[] team1Names = team1Str.substring(5).split(",");
        String[] team2Names = team2Str.substring(5).split(",");
        
        List<NPCData> team1 = new ArrayList<>();
        List<NPCData> team2 = new ArrayList<>();
        
        for (String name : team1Names) {
            NPCData npc = plugin.getNpcManager().getNPC(name.trim());
            if (npc != null) team1.add(npc);
        }
        
        for (String name : team2Names) {
            NPCData npc = plugin.getNpcManager().getNPC(name.trim());
            if (npc != null) team2.add(npc);
        }
        
        if (team1.isEmpty() || team2.isEmpty()) {
            sender.sendMessage("Invalid teams!");
            return;
        }
        
        Set<String> team1Set = new HashSet<>();
        Set<String> team2Set = new HashSet<>();
        
        for (NPCData npc : team1) {
            team1Set.add(npc.getName());
            List<LivingEntity> targets = new ArrayList<>();
            for (NPCData enemy : team2) {
                targets.add(enemy.getNpcEntity());
            }
            plugin.getCombatManager().setTargets(npc, targets);
            npc.setCurrentTask("COMBAT");
        }
        
        for (NPCData npc : team2) {
            team2Set.add(npc.getName());
            List<LivingEntity> targets = new ArrayList<>();
            for (NPCData enemy : team1) {
                targets.add(enemy.getNpcEntity());
            }
            plugin.getCombatManager().setTargets(npc, targets);
            npc.setCurrentTask("COMBAT");
        }
        
        plugin.getCombatManager().setTeam("team1", team1Set);
        plugin.getCombatManager().setTeam("team2", team2Set);
        
        // Play combat start effects for all
        for (NPCData npc : team1) {
            plugin.getEffectsManager().playCombatStartEffect(npc.getNpcEntity().getLocation());
        }
        for (NPCData npc : team2) {
            plugin.getEffectsManager().playCombatStartEffect(npc.getNpcEntity().getLocation());
        }
        
        plugin.getMessageManager().send(sender, "fight-start");
    }
    
    private void handleGuard(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("Usage: /wnpc guard <npc> [radius]");
            return;
        }
        
        String name = args[1];
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        double radius = 10.0;
        if (args.length >= 3) {
            try {
                radius = Double.parseDouble(args[2]);
            } catch (NumberFormatException ignored) {}
        }
        
        final double finalRadius = radius;
        
        clearAllStates(data);
        
        org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
            data.setGuardRadius(finalRadius);
            data.setCurrentTask("GUARD");
            data.setAiEnabled(true);
            plugin.getGuardManager().startGuarding(data, data.getLocation(), finalRadius);
            plugin.getNpcManager().saveAll();
            
            plugin.getEffectsManager().playGuardEffect(data.getNpcEntity().getLocation());
        }, 10L);
        
        sender.sendMessage("§a" + name + " is now guarding with radius §e" + radius);
    }
    
    private void handlePatrol(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (args.length < 3) {
            sender.sendMessage("Usage: /wnpc patrol <npc> <add|start|list|clear>");
            return;
        }
        
        String name = args[1];
        String action = args[2].toLowerCase();
        
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        switch (action) {
            case "add" -> {
                Location loc = player.getLocation();
                plugin.getPatrolManager().addWaypoint(data, loc);
                plugin.getNpcManager().saveAll();
                
                Map<String, String> addMap = new HashMap<>();
                addMap.put("npc", name);
                addMap.put("x", String.format("%.1f", loc.getX()));
                addMap.put("y", String.format("%.1f", loc.getY()));
                addMap.put("z", String.format("%.1f", loc.getZ()));
                plugin.getMessageManager().send(sender, "patrol-add", addMap);
            }
            case "start" -> {
                if (data.getPatrolWaypoints().isEmpty()) {
                    plugin.getMessageManager().send(sender, "patrol-no-waypoints", "npc", name);
                    return;
                }
                
                clearAllStates(data);
                
                org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                    data.setAiEnabled(true);
                    data.setCurrentTask("PATROL");
                    plugin.getPatrolManager().startPatrol(data);
                    
                    plugin.getEffectsManager().playPatrolStartEffect(data.getNpcEntity().getLocation());
                    plugin.getNpcManager().saveAll();
                }, 10L);
                
                sender.sendMessage("§a" + name + " started patrolling with §e" + data.getPatrolWaypoints().size() + " §awaypoints!");
            }
            case "list" -> {
                if (data.getPatrolWaypoints().isEmpty()) {
                    plugin.getMessageManager().send(sender, "patrol-no-waypoints", "npc", name);
                    return;
                }
                
                Map<String, String> headerMap = new HashMap<>();
                headerMap.put("name", name);
                plugin.getMessageManager().send(sender, "patrol-list-header", headerMap);
                
                int index = 1;
                for (Location loc : data.getPatrolWaypoints()) {
                    Map<String, String> entryMap = new HashMap<>();
                    entryMap.put("index", String.valueOf(index++));
                    entryMap.put("x", String.format("%.1f", loc.getX()));
                    entryMap.put("y", String.format("%.1f", loc.getY()));
                    entryMap.put("z", String.format("%.1f", loc.getZ()));
                    plugin.getMessageManager().send(sender, "patrol-list-entry", entryMap);
                }
            }
            case "clear" -> {
                plugin.getPatrolManager().clearWaypoints(data);
                plugin.getNpcManager().saveAll();
                plugin.getMessageManager().send(sender, "patrol-clear", "npc", name);
            }
        }
    }
    
    private void handleBuild(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /wnpc build <npc> <type>");
            sender.sendMessage("Types: house, castle, tower, shelter");
            return;
        }
        
        String name = args[1];
        String type = args[2].toLowerCase();
        
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        if (data.getNpcEntity() == null || !data.getNpcEntity().isValid()) {
            sender.sendMessage("§cNPC is not spawned!");
            return;
        }
        
        if (!List.of("house", "castle", "tower", "shelter").contains(type)) {
            sender.sendMessage("§cInvalid build type! Use: house, castle, tower, or shelter");
            return;
        }
        
        plugin.getCombatManager().clearTargets(data);
        plugin.getMovementManager().stopMovement(data);
        plugin.getPatrolManager().stopPatrol(data);
        plugin.getGuardManager().stopGuarding(data);
        data.setFollowTarget(null);
        
        Location buildLoc = data.getNpcEntity().getLocation().clone().add(3, 0, 0);
        data.setAiEnabled(true);
        plugin.getBuildManager().startBuilding(data, type, buildLoc);
        
        plugin.getEffectsManager().playBuildStartEffect(data.getNpcEntity().getLocation());
        
        sender.sendMessage("§a" + name + " is now building a §e" + type + "§a!");
        sender.sendMessage("§7Building at: §e" + 
            String.format("%.0f, %.0f, %.0f", buildLoc.getX(), buildLoc.getY(), buildLoc.getZ()));
    }
    
    private void handleStyle(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage("Usage: /wnpc style <npc> <attack|defense> <style>");
            return;
        }
        
        String name = args[1];
        String type = args[2].toLowerCase();
        String styleName = args[3].toUpperCase();
        
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        try {
            FightStyle style = FightStyle.valueOf(styleName);
            
            if (type.equals("attack")) {
                data.setAttackStyle(style);
            } else if (type.equals("defense")) {
                data.setDefenseStyle(style);
            } else {
                sender.sendMessage("Type must be 'attack' or 'defense'");
                return;
            }
            
            Map<String, String> styleMap = new HashMap<>();
            styleMap.put("type", type);
            styleMap.put("style", styleName);
            styleMap.put("npc", name);
            
            // Play style change effect
            plugin.getEffectsManager().playStyleChangeEffect(data.getNpcEntity().getLocation());
            
            plugin.getMessageManager().send(sender, "style-set", styleMap);
        } catch (IllegalArgumentException e) {
            sender.sendMessage("Invalid style! Available: LT5, LT4, LT3, LT2, LT1, HT5, HT4, HT3, HT2, HT1");
        }
    }
    
    private void handleWear(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) return;
        if (args.length < 3) {
            sender.sendMessage("Usage: /wnpc wear <npc> <hand|offhand|helmet|chest|legs|boots>");
            return;
        }
        
        String name = args[1];
        String slot = args[2].toLowerCase();
        
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType().isAir()) {
            plugin.getMessageManager().send(sender, "wear-no-item");
            return;
        }
        
        data.getEquipment().put(slot, item.clone());
        
        Player npc = data.getNpcEntity();
        if (npc == null) {
            sender.sendMessage("§cNPC is not spawned!");
            return;
        }
        
        switch (slot) {
            case "hand" -> npc.getInventory().setItemInMainHand(item.clone());
            case "offhand" -> npc.getInventory().setItemInOffHand(item.clone());
            case "helmet" -> npc.getInventory().setHelmet(item.clone());
            case "chest" -> npc.getInventory().setChestplate(item.clone());
            case "legs" -> npc.getInventory().setLeggings(item.clone());
            case "boots" -> npc.getInventory().setBoots(item.clone());
        }
        
        // Update equipment immediately
        npc.updateInventory();
        
        // Force refresh for all players
        for (org.bukkit.entity.Player online : org.bukkit.Bukkit.getOnlinePlayers()) {
            online.hidePlayer(plugin, npc);
        }
        
        org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
            for (org.bukkit.entity.Player online : org.bukkit.Bukkit.getOnlinePlayers()) {
                online.showPlayer(plugin, npc);
            }
        }, 3L);
        
        Map<String, String> wearMap = new HashMap<>();
        wearMap.put("slot", slot);
        wearMap.put("npc", name);
        
        // Play equip effect at NPC current location
        plugin.getEffectsManager().playEquipEffect(npc.getLocation());
        
        plugin.getMessageManager().send(sender, "wear-success", wearMap);
        
        // Save equipment
        plugin.getNpcManager().saveAll();
    }
    
    private void handleClearWear(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("Usage: /wnpc clearwear <npc>");
            return;
        }
        
        String name = args[1];
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        data.getEquipment().clear();
        
        Player npc = data.getNpcEntity();
        npc.getInventory().clear();
        
        plugin.getMessageManager().send(sender, "clearwear-success", "npc", name);
    }
    
    private void handleStart(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("Usage: /wnpc start <npc|all>");
            return;
        }
        
        String target = args[1];
        
        if (target.equalsIgnoreCase("all")) {
            for (NPCData data : plugin.getNpcManager().getAllNPCs()) {
                data.setAiEnabled(true);
            }
            plugin.getMessageManager().send(sender, "start-all-success");
        } else {
            NPCData data = plugin.getNpcManager().getNPC(target);
            if (data == null) {
                plugin.getMessageManager().send(sender, "invalid-npc", "npc", target);
                return;
            }
            
            data.setAiEnabled(true);
            plugin.getMessageManager().send(sender, "start-success", "npc", target);
        }
    }
    
    private void handleStop(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("Usage: /wnpc stop <npc|all>");
            return;
        }
        
        String target = args[1];
        
        if (target.equalsIgnoreCase("all")) {
            for (NPCData data : plugin.getNpcManager().getAllNPCs()) {
                data.setAiEnabled(false);
            }
            plugin.getMessageManager().send(sender, "stop-all-success");
        } else {
            NPCData data = plugin.getNpcManager().getNPC(target);
            if (data == null) {
                plugin.getMessageManager().send(sender, "invalid-npc", "npc", target);
                return;
            }
            
            data.setAiEnabled(false);
            plugin.getMessageManager().send(sender, "stop-success", "npc", target);
        }
    }
    
    private void handleRename(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /wnpc rename <npc> <newname>");
            return;
        }
        
        String oldName = args[1];
        String newName = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
        
        NPCData data = plugin.getNpcManager().getNPC(oldName);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", oldName);
            return;
        }
        
        Player npc = data.getNpcEntity();
        if (npc == null) {
            sender.sendMessage("§cNPC is not spawned!");
            return;
        }
        
        // Update Citizens NPC name
        net.citizensnpcs.api.npc.NPC citizenNPC = net.citizensnpcs.api.CitizensAPI.getNPCRegistry().getNPC(npc);
        if (citizenNPC != null) {
            citizenNPC.setName(newName);
        }
        
        // Update entity display name
        data.setDisplayName(newName);
        npc.setDisplayName(newName);
        npc.setCustomName(newName);
        npc.setCustomNameVisible(true);
        
        // Force instant visual update
        org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> {
            for (org.bukkit.entity.Player online : org.bukkit.Bukkit.getOnlinePlayers()) {
                online.hidePlayer(plugin, npc);
            }
            org.bukkit.Bukkit.getScheduler().runTask(plugin, () -> {
                for (org.bukkit.entity.Player online : org.bukkit.Bukkit.getOnlinePlayers()) {
                    online.showPlayer(plugin, npc);
                }
            });
        });
        
        plugin.getNpcManager().saveAll();
        sender.sendMessage("§a✓ Renamed to §e" + newName + "§a instantly!");
    }
    
    private void handleReloadSkin(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage("Usage: /wnpc reloadskin <npc> <mojangUsername>");
            return;
        }
        
        String name = args[1];
        String skinOwner = args[2];
        
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        if (data.getNpcEntity() == null) {
            sender.sendMessage("§cNPC is not spawned!");
            return;
        }
        
        sender.sendMessage("§e⌛ Loading skin: §f" + skinOwner + "§e...");
        
        // Update skin owner
        data.setSkinOwner(skinOwner);
        
        // Get Citizens NPC
        net.citizensnpcs.api.npc.NPC citizenNPC = net.citizensnpcs.api.CitizensAPI.getNPCRegistry().getNPC(data.getNpcEntity());
        if (citizenNPC == null) {
            sender.sendMessage("§cCitizens NPC not found!");
            return;
        }
        
        // Save current location and equipment
        org.bukkit.Location loc = data.getNpcEntity().getLocation();
        Map<String, ItemStack> equipment = new HashMap<>(data.getEquipment());
        String currentTask = data.getCurrentTask();
        boolean aiEnabled = data.isAiEnabled();
        
        // Apply skin using Citizens trait
        citizenNPC.getOrAddTrait(net.citizensnpcs.trait.SkinTrait.class).setSkinName(skinOwner, true);
        
        // Respawn to apply skin
        citizenNPC.despawn();
        
        org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
            citizenNPC.spawn(loc);
            
            org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                Player npcEntity = (Player) citizenNPC.getEntity();
                if (npcEntity != null) {
                    data.setNpcEntity(npcEntity);
                    
                    // Reapply equipment
                    for (Map.Entry<String, ItemStack> entry : equipment.entrySet()) {
                        ItemStack item = entry.getValue();
                        if (item == null) continue;
                        
                        switch (entry.getKey()) {
                            case "hand" -> npcEntity.getInventory().setItemInMainHand(item);
                            case "offhand" -> npcEntity.getInventory().setItemInOffHand(item);
                            case "helmet" -> npcEntity.getInventory().setHelmet(item);
                            case "chest" -> npcEntity.getInventory().setChestplate(item);
                            case "legs" -> npcEntity.getInventory().setLeggings(item);
                            case "boots" -> npcEntity.getInventory().setBoots(item);
                        }
                    }
                    npcEntity.updateInventory();
                    
                    // Restore state
                    data.setCurrentTask(currentTask);
                    data.setAiEnabled(aiEnabled);
                    npcEntity.setGravity(true);
                }
                
                plugin.getNpcManager().saveAll();
                sender.sendMessage("§a✓ Skin applied: §e" + skinOwner + "§a to §e" + name);
            }, 10L);
        }, 5L);
    }
    
    private void handleReset(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("Usage: /wnpc reset <npc>");
            return;
        }
        
        String name = args[1];
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        data.setCurrentTask("IDLE");
        data.setAiEnabled(true);
        plugin.getCombatManager().clearTargets(data);
        plugin.getMovementManager().stopMovement(data);
        plugin.getPatrolManager().stopPatrol(data);
        
        plugin.getMessageManager().send(sender, "reset-success", "npc", name);
    }
    
    private void handleReload(CommandSender sender) {
        plugin.reload();
        plugin.getMessageManager().send(sender, "reload-success");
    }
    
    private void handleResumeAll(CommandSender sender) {
        boolean success = plugin.getNpcManager().resumeAll();
        
        if (!success) {
            sender.sendMessage("§c⚠ NPCs have already been resumed!");
            sender.sendMessage("§7This command can only be used once per server restart.");
            return;
        }
        
        sender.sendMessage("§e§l⟳ Resuming All NPCs...");
        sender.sendMessage("§7Loading NPC data and tasks...");
        
        Collection<NPCData> allNPCs = plugin.getNpcManager().getAllNPCs();
        int total = allNPCs.size();
        
        org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
            int resumed = 0;
            for (NPCData data : allNPCs) {
                String task = data.getCurrentTask();
                
                if ("GUARD".equals(task)) {
                    sender.sendMessage("§a✓ Resumed §e" + data.getName() + "§a - GUARD");
                    resumed++;
                } else if ("PATROL".equals(task) && !data.getPatrolWaypoints().isEmpty()) {
                    sender.sendMessage("§a✓ Resumed §e" + data.getName() + "§a - PATROL with " + 
                        data.getPatrolWaypoints().size() + " waypoints");
                    resumed++;
                } else if ("FOLLOW".equals(task) && data.getFollowTarget() != null) {
                    sender.sendMessage("§a✓ Resumed §e" + data.getName() + "§a - FOLLOW " + data.getFollowTarget());
                    resumed++;
                } else {
                    sender.sendMessage("§7○ " + data.getName() + " - IDLE");
                }
            }
            
            if (total == 0) {
                sender.sendMessage("§cNo NPCs found to resume!");
            } else {
                sender.sendMessage("§a§l✓ All NPCs Resumed! §7(" + total + " total)");
            }
        }, 50L);
    }
    
    private void handleInventory(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command!");
            return;
        }
        
        if (args.length < 2) {
            sender.sendMessage("Usage: /wnpc inventory <npc>");
            return;
        }
        
        String name = args[1];
        NPCData data = plugin.getNpcManager().getNPC(name);
        if (data == null) {
            plugin.getMessageManager().send(sender, "invalid-npc", "npc", name);
            return;
        }
        
        if (data.getNpcEntity() == null) {
            sender.sendMessage("§cNPC is not spawned!");
            return;
        }
        
        plugin.getInventoryGUI().openInventory(player, data);
        sender.sendMessage("§aOpened inventory of §e" + name);
    }
    
    private void handleTeam(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§e/wnpc team create <name>");
            sender.sendMessage("§e/wnpc team delete <name>");
            sender.sendMessage("§e/wnpc team add <team> <member>");
            sender.sendMessage("§e/wnpc team addallnpc <team>");
            sender.sendMessage("§e/wnpc team remove <member>");
            sender.sendMessage("§e/wnpc team list");
            sender.sendMessage("§e/wnpc team info <name>");
            sender.sendMessage("§e/wnpc team war <team1> <team2>");
            sender.sendMessage("§e/wnpc team respawn <team>");
            return;
        }
        
        String action = args[1].toLowerCase();
        
        switch (action) {
            case "create" -> {
                if (args.length < 3) {
                    sender.sendMessage("§cUsage: /wnpc team create <name>");
                    return;
                }
                String name = args[2];
                if (plugin.getTeamManager().createTeam(name)) {
                    sender.sendMessage("§a§l✓ Team created: §e" + name);
                } else {
                    sender.sendMessage("§c§l✗ Team already exists!");
                }
            }
            
            case "delete" -> {
                if (args.length < 3) {
                    sender.sendMessage("§cUsage: /wnpc team delete <name>");
                    return;
                }
                String name = args[2];
                if (plugin.getTeamManager().deleteTeam(name)) {
                    sender.sendMessage("§a§l✓ Team deleted: §e" + name);
                } else {
                    sender.sendMessage("§c§l✗ Team not found!");
                }
            }
            
            case "add" -> {
                if (args.length < 4) {
                    sender.sendMessage("§cUsage: /wnpc team add <team> <member>");
                    return;
                }
                String teamName = args[2];
                String memberName = args[3];
                
                // Check if team exists
                if (plugin.getTeamManager().getTeam(teamName) == null) {
                    sender.sendMessage("§c§l✗ Team '" + teamName + "' does not exist!");
                    return;
                }
                
                // Check if member already in a team
                String existingTeam = plugin.getTeamManager().getMemberTeam(memberName);
                if (existingTeam != null) {
                    sender.sendMessage("§c§l✗ " + memberName + " is already in team: §e" + existingTeam);
                    sender.sendMessage("§7Remove them first with: §e/wnpc team remove " + memberName);
                    return;
                }
                
                // Check if member exists (NPC or Player)
                NPCData npc = plugin.getNpcManager().getNPC(memberName);
                Player player = Bukkit.getPlayer(memberName);
                
                if (npc == null && player == null) {
                    sender.sendMessage("§c§l✗ NPC or Player '" + memberName + "' not found!");
                    return;
                }
                
                if (plugin.getTeamManager().addMember(teamName, memberName)) {
                    String type = player != null ? "§b[PLAYER]" : "§a[NPC]";
                    sender.sendMessage("§a§l✓ Added " + type + " §e" + memberName + "§a to team §e" + teamName);
                    sender.sendMessage("§7Member is now in TEAM state (AI disabled until war starts)");
                } else {
                    sender.sendMessage("§c§l✗ Failed to add member!");
                }
            }
            
            case "addallnpc" -> {
                if (args.length < 3) {
                    sender.sendMessage("§cUsage: /wnpc team addallnpc <team>");
                    return;
                }
                String teamName = args[2];
                
                // Check if team exists
                if (plugin.getTeamManager().getTeam(teamName) == null) {
                    sender.sendMessage("§c§l✗ Team '" + teamName + "' does not exist!");
                    return;
                }
                
                Collection<NPCData> allNPCs = plugin.getNpcManager().getAllNPCs();
                if (allNPCs.isEmpty()) {
                    sender.sendMessage("§c§l✗ No NPCs found on server!");
                    return;
                }
                
                int added = 0;
                int skipped = 0;
                
                for (NPCData npc : allNPCs) {
                    String npcName = npc.getName();
                    
                    // Check if already in a team
                    String existingTeam = plugin.getTeamManager().getMemberTeam(npcName);
                    if (existingTeam != null) {
                        skipped++;
                        continue;
                    }
                    
                    if (plugin.getTeamManager().addMember(teamName, npcName)) {
                        added++;
                    }
                }
                
                sender.sendMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━");
                sender.sendMessage("§a§l✓ Added All NPCs to Team: §e" + teamName);
                sender.sendMessage("");
                sender.sendMessage("§a✓ Added: §f" + added + " NPCs");
                if (skipped > 0) {
                    sender.sendMessage("§e⚠ Skipped: §f" + skipped + " §7(already in teams)");
                }
                sender.sendMessage("§7All NPCs are now in TEAM state");
                sender.sendMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━");
            }
            
            case "remove" -> {
                if (args.length < 3) {
                    sender.sendMessage("§cUsage: /wnpc team remove <member>");
                    return;
                }
                String memberName = args[2];
                
                if (plugin.getTeamManager().removeMember(memberName)) {
                    sender.sendMessage("§a§l✓ Removed §e" + memberName + "§a from their team");
                } else {
                    sender.sendMessage("§c§l✗ Member not in any team!");
                }
            }
            
            case "list" -> {
                Collection<TeamManager.Team> teams = plugin.getTeamManager().getAllTeams();
                if (teams.isEmpty()) {
                    sender.sendMessage("§cNo teams created yet!");
                    return;
                }
                
                sender.sendMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━");
                sender.sendMessage("§e§lTEAMS §7(" + teams.size() + ")");
                sender.sendMessage("");
                
                for (TeamManager.Team team : teams) {
                    sender.sendMessage("§6▶ §e" + team.name + "§7 - §f" + team.members.size() + " members");
                }
                sender.sendMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━");
            }
            
            case "info" -> {
                if (args.length < 3) {
                    sender.sendMessage("§cUsage: /wnpc team info <name>");
                    return;
                }
                String name = args[2];
                TeamManager.Team team = plugin.getTeamManager().getTeam(name);
                
                if (team == null) {
                    sender.sendMessage("§c§l✗ Team not found!");
                    return;
                }
                
                sender.sendMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━");
                sender.sendMessage("§e§lTEAM: §6" + team.name);
                sender.sendMessage("§7Members: §f" + team.members.size());
                sender.sendMessage("");
                
                for (String member : team.members) {
                    Player player = Bukkit.getPlayer(member);
                    String type = player != null ? "§b[PLAYER]" : "§7[NPC]";
                    String status = "§a✓";
                    
                    NPCData npc = plugin.getNpcManager().getNPC(member);
                    if (npc != null && npc.getNpcEntity() != null) {
                        if (npc.getNpcEntity().isDead()) status = "§c✗";
                    } else if (player != null) {
                        if (player.isDead()) status = "§c✗";
                    }
                    
                    sender.sendMessage("  " + status + " " + type + " §f" + member);
                }
                sender.sendMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━");
            }
            
            case "war" -> {
                if (args.length < 4) {
                    sender.sendMessage("§cUsage: /wnpc team war <team1> <team2>");
                    return;
                }
                
                if (plugin.getTeamManager().isInWar()) {
                    sender.sendMessage("§c§l✗ A war is already in progress!");
                    return;
                }
                
                String team1Name = args[2];
                String team2Name = args[3];
                
                if (plugin.getTeamManager().startWar(team1Name, team2Name)) {
                    Bukkit.broadcastMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                    Bukkit.broadcastMessage("§c§l⚔ WAR STARTED ⚔");
                    Bukkit.broadcastMessage("");
                    Bukkit.broadcastMessage("§6" + team1Name + " §7vs §6" + team2Name);
                    Bukkit.broadcastMessage("");
                    Bukkit.broadcastMessage("§7Fight to the death!");
                    Bukkit.broadcastMessage("§8§m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
                    
                    // Play war start sound
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 0.5f);
                    }
                } else {
                    sender.sendMessage("§c§l✗ Invalid teams or teams are empty!");
                }
            }
            
            case "respawn" -> {
                if (args.length < 3) {
                    sender.sendMessage("§cUsage: /wnpc team respawn <team>");
                    return;
                }
                String teamName = args[2];
                
                if (plugin.getTeamManager().respawnTeam(teamName)) {
                    sender.sendMessage("§a§l✓ Respawned team: §e" + teamName);
                } else {
                    sender.sendMessage("§c§l✗ Team not found or no dead members!");
                }
            }
        }
    }
}

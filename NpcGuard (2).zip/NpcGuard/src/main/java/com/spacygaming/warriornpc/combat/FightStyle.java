package com.spacygaming.warriornpc.combat;

public enum FightStyle {
    
    LT5(18, 0.8, 0.7, 0.6, true),
    LT4(16, 0.7, 0.6, 0.5, true),
    LT3(14, 0.6, 0.5, 0.4, true),
    LT2(12, 0.5, 0.3, 0.3, true),
    LT1(20, 0.9, 0.1, 0.1, true),
    
    HT5(2, 0.3, 0.9, 0.8, false),
    HT4(3, 0.4, 0.7, 0.6, false),
    HT3(5, 0.5, 0.5, 0.4, false),
    HT2(7, 0.6, 0.3, 0.2, false),
    HT1(10, 0.8, 0.0, 0.0, false);
    
    private final int cps;
    private final double aggression;
    private final double defenseFreq;
    private final double shieldUsage;
    private final boolean fastTick;
    
    FightStyle(int cps, double aggression, double defenseFreq, double shieldUsage, boolean fastTick) {
        this.cps = cps;
        this.aggression = aggression;
        this.defenseFreq = defenseFreq;
        this.shieldUsage = shieldUsage;
        this.fastTick = fastTick;
    }
    
    public int getCps() { return cps; }
    public double getAggression() { return aggression; }
    public double getDefenseFrequency() { return defenseFreq; }
    public double getShieldUsage() { return shieldUsage; }
    public boolean isFastTick() { return fastTick; }
    
    public int getAttackDelay() {
        return 20 / cps;
    }
}

package com.spacygaming.warriornpc.services;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public class NPCTickService {
    
    private final WarriorNPCPlugin plugin;
    private BukkitTask task;
    
    public NPCTickService(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void start() {
        int interval = plugin.getConfigManager().getTickInterval();
        
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (NPCData data : plugin.getNpcManager().getAllNPCs()) {
                if (!data.isAiEnabled()) continue;
                
                try {
                    tickNPC(data);
                } catch (Exception e) {
                    // Silently catch errors to prevent spam
                }
            }
        }, 0L, interval);
    }
    
    public void stop() {
        if (task != null) {
            task.cancel();
        }
    }
    
    private void tickNPC(NPCData data) {
        if (data.getNpcEntity() == null || !data.getNpcEntity().isValid()) return;
        
        Player npc = data.getNpcEntity();
        npc.setGravity(true);
        npc.setFlying(false);
        npc.setAllowFlight(false);
        npc.setCollidable(true);
        
        // WAR state - always vulnerable for knockback
        if ("WAR".equals(data.getCurrentTask())) {
            npc.setInvulnerable(false);
        } else {
            npc.setInvulnerable(false);
        }
        
        if (Math.random() < 0.02) {
            plugin.getEffectsManager().playAmbientEffect(data);
        }
        
        if (plugin.getCombatManager().isInCombat(data)) {
            plugin.getCombatManager().tick(data);
            return;
        }
        
        if (data.getCurrentTask().equals("COMBAT") || data.getCurrentTask().equals("DUEL")) {
            if (data.getFollowTarget() != null) {
                data.setCurrentTask("FOLLOW");
            } else if (plugin.getGuardManager().isGuarding(data)) {
                data.setCurrentTask("GUARD");
            } else if (plugin.getPatrolManager().isPatrolling(data)) {
                data.setCurrentTask("PATROL");
            } else {
                data.setCurrentTask("IDLE");
            }
        }
        
        String task = data.getCurrentTask();
        
        switch (task) {
            case "COMBAT", "DUEL" -> {}
            case "PATROL" -> plugin.getPatrolManager().tick(data);
            case "GUARD" -> plugin.getGuardManager().tick(data);
            case "FOLLOW" -> tickFollow(data);
            case "IDLE" -> tickIdle(data);
            default -> {
                if (task.startsWith("BUILD_")) {
                    plugin.getBuildManager().tick(data);
                }
            }
        }
    }
    
    private void tickFollow(NPCData data) {
        String targetName = data.getFollowTarget();
        if (targetName == null) {
            data.setCurrentTask("IDLE");
            return;
        }
        
        Player npc = data.getNpcEntity();
        if (npc == null || !npc.isValid()) return;
        
        npc.setGravity(true);
        npc.setCollidable(true);
        npc.setFlying(false);
        npc.setAllowFlight(false);
        
        Player targetPlayer = Bukkit.getPlayer(targetName);
        if (targetPlayer == null) {
            NPCData targetNPC = plugin.getNpcManager().getNPC(targetName);
            if (targetNPC != null && targetNPC.getNpcEntity() != null) {
                targetPlayer = targetNPC.getNpcEntity();
            }
        }
        
        if (targetPlayer != null && targetPlayer.isValid()) {
            if (!npc.getWorld().equals(targetPlayer.getWorld())) return;
            
            double distance = npc.getLocation().distance(targetPlayer.getLocation());
            
            if (distance > 5.0 || !plugin.getMovementManager().isFollowing(data)) {
                plugin.getMovementManager().followEntity(data, targetPlayer);
            }
        }
    }
    
    private void tickIdle(NPCData data) {
        Player npc = data.getNpcEntity();
        if (npc == null || !npc.isValid()) return;
        
        npc.setGravity(true);
        npc.setCollidable(true);
        npc.setFlying(false);
        npc.setAllowFlight(false);
        
        org.bukkit.Location npcLoc = npc.getLocation();
        double detectionRange = 15.0;
        
        java.util.List<org.bukkit.entity.Monster> nearbyMobs = npc.getWorld()
            .getNearbyEntities(npcLoc, detectionRange, detectionRange, detectionRange).stream()
            .filter(e -> e instanceof org.bukkit.entity.Monster)
            .filter(e -> e.isValid() && !((org.bukkit.entity.Monster)e).isDead())
            .map(e -> (org.bukkit.entity.Monster)e)
            .sorted((a, b) -> Double.compare(
                npcLoc.distance(a.getLocation()),
                npcLoc.distance(b.getLocation())
            ))
            .toList();
        
        if (!nearbyMobs.isEmpty()) {
            org.bukkit.entity.Monster mob = nearbyMobs.get(0);
            double distance = npcLoc.distance(mob.getLocation());
            
            if (distance <= 10.0) {
                java.util.List<org.bukkit.entity.LivingEntity> targets = new java.util.ArrayList<>();
                targets.add(mob);
                plugin.getCombatManager().setTargets(data, targets);
                data.setCurrentTask("COMBAT");
            }
        }
    }
}

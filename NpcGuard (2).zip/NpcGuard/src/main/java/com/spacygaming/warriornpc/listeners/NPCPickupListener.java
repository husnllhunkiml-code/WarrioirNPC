package com.spacygaming.warriornpc.listeners;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;

public class NPCPickupListener implements Listener {
    
    private final WarriorNPCPlugin plugin;
    
    public NPCPickupListener(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onItemPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        
        NPC npc = CitizensAPI.getNPCRegistry().getNPC(player);
        if (npc == null) return;
        
        NPCData data = null;
        for (NPCData npcData : plugin.getNpcManager().getAllNPCs()) {
            if (npcData.getNpcEntity() != null && npcData.getNpcEntity().equals(player)) {
                data = npcData;
                break;
            }
        }
        
        if (data == null) return;
        
        Item item = event.getItem();
        ItemStack itemStack = item.getItemStack();
        
        player.getInventory().addItem(itemStack);
        
        player.getWorld().playSound(player.getLocation(), 
            org.bukkit.Sound.ENTITY_ITEM_PICKUP, 1.0f, 1.0f);
    }
    
    @EventHandler
    public void onItemDropNearNPC(PlayerDropItemEvent event) {
        Player dropper = event.getPlayer();
        Item item = event.getItemDrop();
        ItemStack itemStack = item.getItemStack();
        
        org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!item.isValid() || item.isDead()) return;
            
            for (NPCData data : plugin.getNpcManager().getAllNPCs()) {
                Player npc = data.getNpcEntity();
                if (npc == null || !npc.isValid()) continue;
                
                if (npc.getLocation().distance(item.getLocation()) < 1.5) {
                    npc.getInventory().addItem(itemStack.clone());
                    item.remove();
                    
                    npc.getWorld().playSound(npc.getLocation(), 
                        org.bukkit.Sound.ENTITY_ITEM_PICKUP, 1.0f, 1.0f);
                    
                    dropper.sendMessage("§a" + data.getName() + " picked up the item!");
                    break;
                }
            }
        }, 10L);
    }
}

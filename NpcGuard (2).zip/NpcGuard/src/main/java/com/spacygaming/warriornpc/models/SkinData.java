package com.spacygaming.warriornpc.models;

public class SkinData {
    
    private final String texture;
    private final String signature;
    private final long cacheTime;
    
    public SkinData(String texture, String signature) {
        this.texture = texture;
        this.signature = signature;
        this.cacheTime = System.currentTimeMillis();
    }
    
    public String getTexture() {
        return texture;
    }
    
    public String getSignature() {
        return signature;
    }
    
    public long getCacheTime() {
        return cacheTime;
    }
    
    public boolean isExpired(int hours) {
        long expireTime = cacheTime + (hours * 3600000L);
        return System.currentTimeMillis() > expireTime;
    }
}

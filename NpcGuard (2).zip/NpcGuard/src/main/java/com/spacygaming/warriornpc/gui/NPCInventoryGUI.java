package com.spacygaming.warriornpc.gui;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class NPCInventoryGUI implements Listener {
    
    private final WarriorNPCPlugin plugin;
    private final Map<Player, NPCData> openInventories = new HashMap<>();
    
    public NPCInventoryGUI(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void openInventory(Player player, NPCData data) {
        Inventory inv = Bukkit.createInventory(null, 54, "§8§l" + data.getName() + "'s Inventory");
        
        // Top row: Armor slots with labels
        inv.setItem(0, createInfoItem(Material.BLACK_STAINED_GLASS_PANE, "§7Armor Slots"));
        inv.setItem(1, createSlotItem(Material.LEATHER_HELMET, "§eHelmet Slot", "§7Click to place helmet"));
        inv.setItem(2, createSlotItem(Material.LEATHER_CHESTPLATE, "§eChestplate Slot", "§7Click to place chestplate"));
        inv.setItem(3, createSlotItem(Material.LEATHER_LEGGINGS, "§eLeggings Slot", "§7Click to place leggings"));
        inv.setItem(4, createSlotItem(Material.LEATHER_BOOTS, "§eBoots Slot", "§7Click to place boots"));
        inv.setItem(5, createInfoItem(Material.BLACK_STAINED_GLASS_PANE, ""));
        inv.setItem(6, createSlotItem(Material.STICK, "§eMain Hand", "§7Click to place weapon/tool"));
        inv.setItem(7, createSlotItem(Material.SHIELD, "§eOff Hand", "§7Click to place shield/item"));
        inv.setItem(8, createInfoItem(Material.BLACK_STAINED_GLASS_PANE, ""));
        
        // Load current equipment
        Player npc = data.getNpcEntity();
        if (npc != null) {
            ItemStack helmet = npc.getInventory().getHelmet();
            ItemStack chest = npc.getInventory().getChestplate();
            ItemStack legs = npc.getInventory().getLeggings();
            ItemStack boots = npc.getInventory().getBoots();
            ItemStack mainHand = npc.getInventory().getItemInMainHand();
            ItemStack offHand = npc.getInventory().getItemInOffHand();
            
            if (helmet != null && !helmet.getType().isAir()) inv.setItem(10, helmet);
            if (chest != null && !chest.getType().isAir()) inv.setItem(11, chest);
            if (legs != null && !legs.getType().isAir()) inv.setItem(12, legs);
            if (boots != null && !boots.getType().isAir()) inv.setItem(13, boots);
            if (mainHand != null && !mainHand.getType().isAir()) inv.setItem(15, mainHand);
            if (offHand != null && !offHand.getType().isAir()) inv.setItem(16, offHand);
        }
        
        // Separator
        for (int i = 18; i < 27; i++) {
            inv.setItem(i, createInfoItem(Material.GRAY_STAINED_GLASS_PANE, "§7NPC Main Inventory"));
        }
        
        // Main inventory slots (27 slots)
        for (int i = 27; i < 54; i++) {
            inv.setItem(i, new ItemStack(Material.AIR));
        }
        
        // Action buttons
        inv.setItem(45, createActionButton(Material.RED_WOOL, "§c§lRemove All Armor", "§7Click to remove all armor"));
        inv.setItem(46, createActionButton(Material.YELLOW_WOOL, "§e§lRemove All Items", "§7Click to clear inventory"));
        inv.setItem(53, createActionButton(Material.GREEN_WOOL, "§a§lSave & Close", "§7Click to save changes"));
        
        player.openInventory(inv);
        openInventories.put(player, data);
    }
    
    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        
        if (!openInventories.containsKey(player)) return;
        
        NPCData data = openInventories.get(player);
        Inventory inv = event.getInventory();
        
        int slot = event.getRawSlot();
        
        // Prevent clicking on info panes
        if (slot == 0 || slot == 5 || slot == 8 || (slot >= 18 && slot < 27)) {
            if (event.getCurrentItem() != null && 
                event.getCurrentItem().getType().toString().contains("GLASS_PANE")) {
                event.setCancelled(true);
                return;
            }
        }
        
        // Handle armor/equipment slots
        if (slot >= 10 && slot <= 16) {
            event.setCancelled(true);
            
            ItemStack cursor = event.getCursor();
            ItemStack current = event.getCurrentItem();
            
            Player npc = data.getNpcEntity();
            if (npc == null) return;
            
            // Remove current item
            if (cursor == null || cursor.getType().isAir()) {
                if (current != null && !current.getType().isAir()) {
                    // Return to player
                    player.getInventory().addItem(current.clone());
                    inv.setItem(slot, new ItemStack(Material.AIR));
                    applyEquipment(npc, data, slot, null);
                }
                return;
            }
            
            // Place new item
            inv.setItem(slot, cursor.clone());
            player.setItemOnCursor(current);
            applyEquipment(npc, data, slot, cursor.clone());
            
            plugin.getEffectsManager().playEquipEffect(npc.getLocation());
            return;
        }
        
        // Handle action buttons
        if (slot == 45) { // Remove all armor
            event.setCancelled(true);
            Player npc = data.getNpcEntity();
            if (npc != null) {
                npc.getInventory().setHelmet(null);
                npc.getInventory().setChestplate(null);
                npc.getInventory().setLeggings(null);
                npc.getInventory().setBoots(null);
                
                inv.setItem(10, new ItemStack(Material.AIR));
                inv.setItem(11, new ItemStack(Material.AIR));
                inv.setItem(12, new ItemStack(Material.AIR));
                inv.setItem(13, new ItemStack(Material.AIR));
                
                data.getEquipment().remove("helmet");
                data.getEquipment().remove("chest");
                data.getEquipment().remove("legs");
                data.getEquipment().remove("boots");
                
                player.sendMessage("§aRemoved all armor from " + data.getName());
            }
        }
        
        if (slot == 46) { // Remove all items
            event.setCancelled(true);
            Player npc = data.getNpcEntity();
            if (npc != null) {
                npc.getInventory().clear();
                data.getEquipment().clear();
                
                for (int i = 10; i <= 16; i++) {
                    inv.setItem(i, new ItemStack(Material.AIR));
                }
                
                player.sendMessage("§aCleared inventory of " + data.getName());
            }
        }
        
        if (slot == 53) { // Save & close
            event.setCancelled(true);
            player.closeInventory();
            player.sendMessage("§aSaved changes to " + data.getName());
        }
    }
    
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        
        if (openInventories.containsKey(player)) {
            NPCData data = openInventories.remove(player);
            plugin.getNpcManager().saveAll();
        }
    }
    
    private void applyEquipment(Player npc, NPCData data, int slot, ItemStack item) {
        switch (slot) {
            case 10 -> {
                npc.getInventory().setHelmet(item);
                if (item != null && !item.getType().isAir()) {
                    data.getEquipment().put("helmet", item.clone());
                } else {
                    data.getEquipment().remove("helmet");
                }
            }
            case 11 -> {
                npc.getInventory().setChestplate(item);
                if (item != null && !item.getType().isAir()) {
                    data.getEquipment().put("chest", item.clone());
                } else {
                    data.getEquipment().remove("chest");
                }
            }
            case 12 -> {
                npc.getInventory().setLeggings(item);
                if (item != null && !item.getType().isAir()) {
                    data.getEquipment().put("legs", item.clone());
                } else {
                    data.getEquipment().remove("legs");
                }
            }
            case 13 -> {
                npc.getInventory().setBoots(item);
                if (item != null && !item.getType().isAir()) {
                    data.getEquipment().put("boots", item.clone());
                } else {
                    data.getEquipment().remove("boots");
                }
            }
            case 15 -> {
                npc.getInventory().setItemInMainHand(item);
                if (item != null && !item.getType().isAir()) {
                    data.getEquipment().put("hand", item.clone());
                } else {
                    data.getEquipment().remove("hand");
                }
            }
            case 16 -> {
                npc.getInventory().setItemInOffHand(item);
                if (item != null && !item.getType().isAir()) {
                    data.getEquipment().put("offhand", item.clone());
                } else {
                    data.getEquipment().remove("offhand");
                }
            }
        }
        
        npc.updateInventory();
        
        for (org.bukkit.entity.Player online : org.bukkit.Bukkit.getOnlinePlayers()) {
            online.hidePlayer(plugin, npc);
            org.bukkit.Bukkit.getScheduler().runTaskLater(plugin, () -> {
                online.showPlayer(plugin, npc);
            }, 2L);
        }
        
        plugin.getNpcManager().saveAll();
    }
    
    private ItemStack createInfoItem(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            item.setItemMeta(meta);
        }
        return item;
    }
    
    private ItemStack createSlotItem(Material material, String name, String lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(Arrays.asList(lore, "§7Drag items here to equip"));
            item.setItemMeta(meta);
        }
        return item;
    }
    
    private ItemStack createActionButton(Material material, String name, String lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(name);
            meta.setLore(Arrays.asList(lore));
            item.setItemMeta(meta);
        }
        return item;
    }
}

package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import org.bukkit.configuration.file.FileConfiguration;

public class ConfigManager {
    
    private final WarriorNPCPlugin plugin;
    private FileConfiguration config;
    
    public ConfigManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
        reload();
    }
    
    public void reload() {
        plugin.reloadConfig();
        config = plugin.getConfig();
    }
    
    public double getDefaultHealth() {
        return config.getDouble("npc.default-health", 20.0);
    }
    
    public boolean isNameVisible() {
        return config.getBoolean("npc.name-visible", true);
    }
    
    public double getNameVisibleRange() {
        return config.getDouble("npc.name-visible-range", 48.0);
    }
    
    public double getAttackRange() {
        return config.getDouble("combat.attack-range", 3.5);
    }
    
    public double getChaseRange() {
        return config.getDouble("combat.chase-range", 20.0);
    }
    
    public boolean isLosCheckEnabled() {
        return config.getBoolean("combat.los-check", true);
    }
    
    public boolean isFriendlyFireEnabled() {
        return config.getBoolean("combat.friendly-fire", false);
    }
    
    public int getRecalculateTicks() {
        return config.getInt("pathfinding.recalculate-ticks", 10);
    }
    
    public double getMaxPathDistance() {
        return config.getDouble("pathfinding.max-path-distance", 64.0);
    }
    
    public boolean isAvoidWater() {
        return config.getBoolean("pathfinding.avoid-water", true);
    }
    
    public boolean isOpenDoors() {
        return config.getBoolean("pathfinding.open-doors", true);
    }
    
    public int getMaxNpcs() {
        return config.getInt("performance.max-npcs", 200);
    }
    
    public int getTickInterval() {
        return config.getInt("performance.tick-interval", 1);
    }
    
    public boolean isAsyncSkinLoading() {
        return config.getBoolean("performance.async-skin-loading", true);
    }
    
    public boolean isAsyncFileSaving() {
        return config.getBoolean("performance.async-file-saving", true);
    }
    
    public boolean isSkinCacheEnabled() {
        return config.getBoolean("skin.cache-enabled", true);
    }
    
    public int getSkinCacheDuration() {
        return config.getInt("skin.cache-duration-hours", 24);
    }
    
    public String getMojangApiUrl() {
        return config.getString("skin.mojang-api-url", "https://api.mojang.com");
    }
    
    public String getSessionServerUrl() {
        return config.getString("skin.session-server-url", "https://sessionserver.mojang.com");
    }
}

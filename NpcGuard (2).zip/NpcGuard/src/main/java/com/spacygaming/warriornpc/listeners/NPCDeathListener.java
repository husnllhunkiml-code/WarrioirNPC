package com.spacygaming.warriornpc.listeners;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import net.citizensnpcs.api.CitizensAPI;
import net.citizensnpcs.api.npc.NPC;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

public class NPCDeathListener implements Listener {
    
    private final WarriorNPCPlugin plugin;
    
    public NPCDeathListener(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler(priority = EventPriority.MONITOR)
    public void onEntityDeath(EntityDeathEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        
        NPC npc = CitizensAPI.getNPCRegistry().getNPC(player);
        if (npc == null) {
            // Check if it's a real player in a war
            if (plugin.getTeamManager().isInWar()) {
                Player killer = player.getKiller();
                if (killer != null) {
                    plugin.getTeamManager().handleKill(killer.getName(), player.getName());
                }
                plugin.getTeamManager().handleDeath(player.getName());
            }
            return;
        }
        
        NPCData data = null;
        for (NPCData npcData : plugin.getNpcManager().getAllNPCs()) {
            if (npcData.getNpcEntity() != null && npcData.getNpcEntity().equals(player)) {
                data = npcData;
                break;
            }
        }
        
        if (data == null) return;
        
        event.getDrops().clear();
        event.setDroppedExp(0);
        
        // Check if in war
        if (plugin.getTeamManager().isInWar() && "WAR".equals(data.getCurrentTask())) {
            Player killer = player.getKiller();
            if (killer != null) {
                // Check if killer is NPC or player
                NPC killerNpc = CitizensAPI.getNPCRegistry().getNPC(killer);
                if (killerNpc != null) {
                    // Find killer NPC name
                    for (NPCData npcData : plugin.getNpcManager().getAllNPCs()) {
                        if (npcData.getNpcEntity() != null && npcData.getNpcEntity().equals(killer)) {
                            plugin.getTeamManager().handleKill(npcData.getName(), data.getName());
                            break;
                        }
                    }
                } else {
                    // Real player killer
                    plugin.getTeamManager().handleKill(killer.getName(), data.getName());
                }
            }
            
            plugin.getTeamManager().handleDeath(data.getName());
            
            // Don't respawn during war - just clear state
            data.setCurrentTask("WAR_DEAD");
            data.setAiEnabled(false);
            plugin.getCombatManager().clearTargets(data);
            plugin.getMovementManager().stopMovement(data);
            return;
        }
        
        // Set dead NPC to IDLE state
        data.setCurrentTask("IDLE");
        data.setAiEnabled(false);
        plugin.getCombatManager().clearTargets(data);
        plugin.getMovementManager().stopMovement(data);
        
        // Clear combat states for all NPCs in combat
        for (NPCData otherData : plugin.getNpcManager().getAllNPCs()) {
            if (otherData.getCurrentTask().equals("COMBAT")) {
                plugin.getCombatManager().clearTargets(otherData);
                plugin.getMovementManager().stopMovement(otherData);
                otherData.setCurrentTask("IDLE");
                otherData.setAiEnabled(true);
            }
        }
        
        final NPCData finalData = data;
        
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Location respawnLoc = new Location(
                Bukkit.getWorld(finalData.getWorld()),
                finalData.getX(),
                finalData.getY(),
                finalData.getZ(),
                finalData.getYaw(),
                finalData.getPitch()
            );
            
            if (respawnLoc.getWorld() != null) {
                finalData.setHealth(20.0);
                plugin.getNpcManager().spawnNPC(finalData, respawnLoc);
                plugin.getEffectsManager().playSpawnEffect(respawnLoc, finalData.getName());
            }
        }, 100L);
    }
}

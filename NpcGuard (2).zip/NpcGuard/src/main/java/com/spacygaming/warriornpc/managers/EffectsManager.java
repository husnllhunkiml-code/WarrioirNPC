package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.models.NPCData;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.Player;

import java.time.Duration;

public class EffectsManager {
    
    private final WarriorNPCPlugin plugin;
    
    public EffectsManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void playSpawnEffect(Location location, String npcName) {
        World world = location.getWorld();
        if (world == null) return;
        
        // Particle circle effect
        for (int i = 0; i < 360; i += 10) {
            double angle = Math.toRadians(i);
            double x = location.getX() + Math.cos(angle) * 1.5;
            double z = location.getZ() + Math.sin(angle) * 1.5;
            Location particleLoc = new Location(world, x, location.getY() + 0.5, z);
            world.spawnParticle(Particle.ENCHANT, particleLoc, 3, 0.1, 0.1, 0.1, 0.05);
        }
        
        // Central particles - NO TOTEM!
        world.spawnParticle(Particle.FIREWORK, location.clone().add(0, 1, 0), 30, 0.3, 0.5, 0.3, 0.1);
        world.spawnParticle(Particle.END_ROD, location.clone().add(0, 0.5, 0), 15, 0.2, 0.2, 0.2, 0.1);
        
        // Sound effects
        world.playSound(location, Sound.ENTITY_PLAYER_LEVELUP, SoundCategory.MASTER, 1.0f, 1.0f);
        world.playSound(location, Sound.ENTITY_ENDER_DRAGON_FLAP, SoundCategory.MASTER, 0.5f, 1.5f);
        world.playSound(location, Sound.BLOCK_BEACON_ACTIVATE, SoundCategory.MASTER, 0.7f, 1.2f);
        
        // Show title to nearby players
        showSpawnTitle(location, npcName);
        
        // Delayed second wave
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            world.spawnParticle(Particle.SOUL_FIRE_FLAME, location.clone().add(0, 1, 0), 20, 0.3, 0.5, 0.3, 0.05);
            world.playSound(location, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.MASTER, 1.0f, 0.8f);
        }, 10L);
    }
    
    public void playRemoveEffect(Location location, String npcName) {
        World world = location.getWorld();
        if (world == null) return;
        
        // Smoke particles
        world.spawnParticle(Particle.LARGE_SMOKE, location.clone().add(0, 1, 0), 30, 0.3, 0.5, 0.3, 0.05);
        world.spawnParticle(Particle.CLOUD, location.clone().add(0, 1, 0), 20, 0.4, 0.6, 0.4, 0.1);
        world.spawnParticle(Particle.ASH, location.clone().add(0, 1, 0), 25, 0.5, 0.8, 0.5, 0.05);
        
        // Sound
        world.playSound(location, Sound.ENTITY_ENDERMAN_TELEPORT, SoundCategory.MASTER, 1.0f, 0.8f);
        world.playSound(location, Sound.BLOCK_FIRE_EXTINGUISH, SoundCategory.MASTER, 0.5f, 1.0f);
        
        // Show title
        showRemoveTitle(location, npcName);
    }
    
    public void playTeleportEffect(Location from, Location to) {
        World world = from.getWorld();
        if (world == null) return;
        
        // From location particles
        world.spawnParticle(Particle.PORTAL, from.clone().add(0, 1, 0), 50, 0.3, 0.5, 0.3, 0.5);
        world.playSound(from, Sound.ENTITY_ENDERMAN_TELEPORT, SoundCategory.MASTER, 1.0f, 1.0f);
        
        // To location particles (delayed)
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            world.spawnParticle(Particle.PORTAL, to.clone().add(0, 1, 0), 50, 0.3, 0.5, 0.3, 0.5);
            world.spawnParticle(Particle.REVERSE_PORTAL, to.clone().add(0, 1, 0), 30, 0.3, 0.5, 0.3, 0.3);
            world.playSound(to, Sound.ENTITY_ENDERMAN_TELEPORT, SoundCategory.MASTER, 1.0f, 1.2f);
        }, 5L);
    }
    
    public void playCombatStartEffect(Location location) {
        World world = location.getWorld();
        if (world == null) return;
        
        world.spawnParticle(Particle.SWEEP_ATTACK, location.clone().add(0, 1, 0), 5, 0.5, 0.3, 0.5, 0);
        world.spawnParticle(Particle.FLAME, location.clone().add(0, 1, 0), 15, 0.3, 0.5, 0.3, 0.05);
        world.playSound(location, Sound.ENTITY_PLAYER_ATTACK_STRONG, SoundCategory.MASTER, 0.8f, 1.0f);
        world.playSound(location, Sound.ENTITY_BLAZE_SHOOT, SoundCategory.MASTER, 0.5f, 1.5f);
    }
    
    public void playPatrolStartEffect(Location location) {
        World world = location.getWorld();
        if (world == null) return;
        
        world.spawnParticle(Particle.HAPPY_VILLAGER, location.clone().add(0, 1, 0), 20, 0.5, 0.5, 0.5, 0);
        world.playSound(location, Sound.BLOCK_NOTE_BLOCK_BELL, SoundCategory.MASTER, 1.0f, 1.5f);
        world.playSound(location, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, SoundCategory.MASTER, 0.8f, 1.2f);
    }
    
    public void playBuildStartEffect(Location location) {
        World world = location.getWorld();
        if (world == null) return;
        
        world.spawnParticle(Particle.ITEM, location.clone().add(0, 1, 0), 30, 0.5, 0.5, 0.5, 0.1, 
            new org.bukkit.inventory.ItemStack(Material.BRICKS));
        world.playSound(location, Sound.BLOCK_ANVIL_USE, SoundCategory.MASTER, 0.5f, 1.0f);
        world.playSound(location, Sound.ENTITY_VILLAGER_WORK_MASON, SoundCategory.MASTER, 1.0f, 1.0f);
    }
    
    public void playEquipEffect(Location location) {
        World world = location.getWorld();
        if (world == null) return;
        
        world.spawnParticle(Particle.ITEM_SLIME, location.clone().add(0, 1, 0), 10, 0.3, 0.3, 0.3, 0);
        world.playSound(location, Sound.ITEM_ARMOR_EQUIP_DIAMOND, SoundCategory.MASTER, 1.0f, 1.0f);
    }
    
    public void playGuardEffect(Location location) {
        World world = location.getWorld();
        if (world == null) return;
        
        world.spawnParticle(Particle.GLOW, location.clone().add(0, 1, 0), 25, 0.5, 0.5, 0.5, 0.05);
        world.playSound(location, Sound.BLOCK_BELL_USE, SoundCategory.MASTER, 1.0f, 1.0f);
        world.playSound(location, Sound.ITEM_SHIELD_BLOCK, SoundCategory.MASTER, 0.7f, 1.2f);
    }
    
    public void playStyleChangeEffect(Location location) {
        World world = location.getWorld();
        if (world == null) return;
        
        world.spawnParticle(Particle.ENCHANT, location.clone().add(0, 1.5, 0), 30, 0.5, 0.3, 0.5, 0.5);
        world.playSound(location, Sound.BLOCK_ENCHANTMENT_TABLE_USE, SoundCategory.MASTER, 1.0f, 1.0f);
        world.playSound(location, Sound.ENTITY_PLAYER_LEVELUP, SoundCategory.MASTER, 0.5f, 1.5f);
    }
    
    private void showSpawnTitle(Location location, String npcName) {
        Component title = Component.text("⚔ NPC SPAWNED ⚔")
            .color(NamedTextColor.GOLD)
            .decorate(TextDecoration.BOLD);
        
        Component subtitle = Component.text(npcName)
            .color(NamedTextColor.YELLOW)
            .append(Component.text(" has entered the world", NamedTextColor.GRAY));
        
        Title titleObj = Title.title(
            title,
            subtitle,
            Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofMillis(500))
        );
        
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getWorld().equals(location.getWorld()) && 
                player.getLocation().distance(location) <= 50) {
                player.showTitle(titleObj);
            }
        }
    }
    
    private void showRemoveTitle(Location location, String npcName) {
        Component title = Component.text("✖ NPC REMOVED ✖")
            .color(NamedTextColor.RED)
            .decorate(TextDecoration.BOLD);
        
        Component subtitle = Component.text(npcName)
            .color(NamedTextColor.GRAY)
            .append(Component.text(" has been removed", NamedTextColor.DARK_GRAY));
        
        Title titleObj = Title.title(
            title,
            subtitle,
            Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(300))
        );
        
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getWorld().equals(location.getWorld()) && 
                player.getLocation().distance(location) <= 50) {
                player.showTitle(titleObj);
            }
        }
    }
    
    public void showCombatTitle(Player player, String message, NamedTextColor color) {
        Component title = Component.text("⚔ " + message + " ⚔")
            .color(color)
            .decorate(TextDecoration.BOLD);
        
        Title titleObj = Title.title(
            title,
            Component.empty(),
            Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(300))
        );
        
        player.showTitle(titleObj);
    }
    
    public void showActionBar(Player player, String message, NamedTextColor color) {
        player.sendActionBar(Component.text(message).color(color));
    }
    
    public void playAmbientEffect(NPCData data) {
        if (data.getNpcEntity() == null) return;
        
        Location location = data.getNpcEntity().getLocation();
        World world = location.getWorld();
        if (world == null) return;
        
        String task = data.getCurrentTask();
        
        switch (task) {
            case "COMBAT" -> {
                if (Math.random() < 0.1) {
                    world.spawnParticle(Particle.CRIT, location.clone().add(0, 1, 0), 3, 0.3, 0.3, 0.3, 0);
                }
            }
            case "PATROL", "GUARD" -> {
                if (Math.random() < 0.05) {
                    world.spawnParticle(Particle.HAPPY_VILLAGER, location.clone().add(0, 2, 0), 1, 0.1, 0.1, 0.1, 0);
                }
            }
            case "FOLLOW" -> {
                if (Math.random() < 0.08) {
                    world.spawnParticle(Particle.HEART, location.clone().add(0, 2, 0), 1, 0.2, 0.2, 0.2, 0);
                }
            }
        }
        
        if (task.startsWith("BUILD_")) {
            if (Math.random() < 0.15) {
                world.spawnParticle(Particle.ITEM, location.clone().add(0, 1.5, 0), 2, 0.2, 0.2, 0.2, 0,
                    new org.bukkit.inventory.ItemStack(Material.BRICKS));
            }
        }
    }
    
    public void playVictoryEffect(Location location) {
        World world = location.getWorld();
        if (world == null) return;
        
        world.spawnParticle(Particle.FIREWORK, location.clone().add(0, 1, 0), 50, 0.5, 0.8, 0.5, 0.2);
        world.spawnParticle(Particle.TOTEM_OF_UNDYING, location.clone().add(0, 1, 0), 30, 0.3, 0.5, 0.3, 0.1);
        world.spawnParticle(Particle.END_ROD, location.clone().add(0, 0.5, 0), 20, 0.3, 0.3, 0.3, 0.15);
        
        for (int i = 0; i < 360; i += 20) {
            double angle = Math.toRadians(i);
            double x = location.getX() + Math.cos(angle) * 2.0;
            double z = location.getZ() + Math.sin(angle) * 2.0;
            Location particleLoc = new Location(world, x, location.getY() + 1, z);
            world.spawnParticle(Particle.FLAME, particleLoc, 5, 0.1, 0.1, 0.1, 0.05);
        }
        
        world.playSound(location, Sound.UI_TOAST_CHALLENGE_COMPLETE, SoundCategory.MASTER, 1.0f, 1.0f);
        world.playSound(location, Sound.ENTITY_PLAYER_LEVELUP, SoundCategory.MASTER, 1.0f, 1.2f);
        world.playSound(location, Sound.ENTITY_FIREWORK_ROCKET_BLAST, SoundCategory.MASTER, 0.8f, 1.5f);
    }
}

package com.spacygaming.warriornpc.managers;

import com.spacygaming.warriornpc.WarriorNPCPlugin;
import com.spacygaming.warriornpc.combat.FightStyle;
import com.spacygaming.warriornpc.models.NPCData;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CombatManager {
    
    private final WarriorNPCPlugin plugin;
    private final Map<String, List<LivingEntity>> targetMap = new ConcurrentHashMap<>();
    private final Map<String, LivingEntity> currentTarget = new ConcurrentHashMap<>();
    private final Map<String, Integer> attackCooldowns = new ConcurrentHashMap<>();
    private final Map<String, Long> lastAttackTime = new ConcurrentHashMap<>();
    private final Map<String, Set<String>> teams = new ConcurrentHashMap<>();
    
    public CombatManager(WarriorNPCPlugin plugin) {
        this.plugin = plugin;
    }
    
    public void setTarget(NPCData data, LivingEntity target) {
        List<LivingEntity> targets = new ArrayList<>();
        targets.add(target);
        setTargets(data, targets);
    }
    
    public void setTargets(NPCData data, List<LivingEntity> targets) {
        targetMap.put(data.getName(), new ArrayList<>(targets));
        if (!targets.isEmpty()) {
            currentTarget.put(data.getName(), targets.get(0));
        }
    }
    
    public void clearTargets(NPCData data) {
        targetMap.remove(data.getName());
        currentTarget.remove(data.getName());
        data.setCurrentTask("IDLE");
    }
    
    public void setTeam(String teamName, Set<String> members) {
        teams.put(teamName, members);
    }
    
    public String getTeam(NPCData data) {
        for (Map.Entry<String, Set<String>> entry : teams.entrySet()) {
            if (entry.getValue().contains(data.getName())) {
                return entry.getKey();
            }
        }
        return null;
    }
    
    public void tick(NPCData data) {
        if (data.getNpcEntity() == null || !data.isAiEnabled()) return;
        
        Player npc = data.getNpcEntity();
        npc.setGravity(true);
        npc.setCollidable(true);
        npc.setInvulnerable(false);
        npc.setFlying(false);
        npc.setAllowFlight(false);
        
        List<LivingEntity> targets = targetMap.get(data.getName());
        if (targets == null || targets.isEmpty()) return;
        
        targets.removeIf(t -> t.isDead() || !t.isValid());
        if (targets.isEmpty()) {
            clearTargets(data);
            return;
        }
        
        LivingEntity target = selectBestTarget(data, targets);
        if (target == null) {
            clearTargets(data);
            return;
        }
        
        currentTarget.put(data.getName(), target);
        engageCombat(data, target);
    }
    
    private LivingEntity selectBestTarget(NPCData data, List<LivingEntity> targets) {
        Player npc = data.getNpcEntity();
        Location npcLoc = npc.getLocation();
        
        LivingEntity closest = null;
        double minDist = Double.MAX_VALUE;
        
        for (LivingEntity target : targets) {
            // Check if should attack
            if (!shouldAttack(data, target)) continue;
            
            // Don't attack self
            if (target.equals(npc)) continue;
            
            double dist = npcLoc.distance(target.getLocation());
            if (dist < minDist) {
                minDist = dist;
                closest = target;
            }
        }
        
        return closest;
    }
    

    private boolean shouldAttack(NPCData data, LivingEntity target) {
        if (target.isDead() || !target.isValid()) return false;
        
        // Don't attack self
        if (target.equals(data.getNpcEntity())) return false;
        
        // Check team
        String team = getTeam(data);
        if (team != null && !plugin.getConfigManager().isFriendlyFireEnabled()) {
            if (target instanceof Player) {
                NPCData targetNPC = plugin.getNpcManager().getNPC(target.getName());
                if (targetNPC != null) {
                    String targetTeam = getTeam(targetNPC);
                    if (team.equals(targetTeam)) {
                        return false;
                    }
                }
            }
        }
        
        return true;
    }
    
    private void engageCombat(NPCData data, LivingEntity target) {
        Player npc = data.getNpcEntity();
        if (npc == null || !npc.isValid() || target == null || target.isDead()) return;
        
        npc.setGravity(true);
        npc.setCollidable(true);
        npc.setInvulnerable(false);
        npc.setFlying(false);
        npc.setAllowFlight(false);
        
        if (!npc.getWorld().equals(target.getWorld())) {
            clearTargets(data);
            return;
        }
        
        Location npcLoc = npc.getLocation();
        Location targetLoc = target.getLocation();
        
        double distance = npcLoc.distance(targetLoc);
        double attackRange = 1.5;
        double chaseRange = 50.0;
        
        if (distance > chaseRange) {
            clearTargets(data);
            return;
        }
        
        plugin.getMovementManager().lookAt(data, target);
        
        if (distance > attackRange) {
            npc.setSprinting(true);
            plugin.getMovementManager().walkTo(data, target);
            return;
        }
        
        plugin.getMovementManager().stopMovement(data);
        npc.setSprinting(false);
        
        // Check Minecraft attack cooldown - must be 100% to prevent double hits
        float cooldown = npc.getAttackCooldown();
        if (cooldown < 1.0f) {
            return; // Wait for full cooldown
        }
        
        // Minimum 1000ms between attacks
        long now = System.currentTimeMillis();
        Long lastAttack = lastAttackTime.get(data.getName());
        
        if (lastAttack != null) {
            long timeSinceLastHit = now - lastAttack;
            if (timeSinceLastHit < 1000) {
                return;
            }
        }
        
        // Perform attack
        npc.attack(target);
        npc.swingMainHand();
        
        // Update tracking
        lastAttackTime.put(data.getName(), now);
        
        npc.getWorld().playSound(npc.getLocation(), 
            org.bukkit.Sound.ENTITY_PLAYER_ATTACK_STRONG, 0.8f, 1.0f);
    }
    
    public List<LivingEntity> getTargets(NPCData data) {
        return targetMap.getOrDefault(data.getName(), new ArrayList<>());
    }
    
    public LivingEntity getCurrentTarget(NPCData data) {
        return currentTarget.get(data.getName());
    }
    
    public boolean isInCombat(NPCData data) {
        return !getTargets(data).isEmpty();
    }
}

package com.spacygaming.warriornpc;

import com.spacygaming.warriornpc.commands.NPCCommandExecutor;
import com.spacygaming.warriornpc.commands.NPCTabCompleter;
import com.spacygaming.warriornpc.gui.NPCInventoryGUI;
import com.spacygaming.warriornpc.listeners.NPCDeathListener;
import com.spacygaming.warriornpc.listeners.NPCPickupListener;
import com.spacygaming.warriornpc.managers.*;
import com.spacygaming.warriornpc.services.*;
import org.bukkit.plugin.java.JavaPlugin;

public class WarriorNPCPlugin extends JavaPlugin {
    
    private static WarriorNPCPlugin instance;
    
    private ConfigManager configManager;
    private MessageManager messageManager;
    private NPCManager npcManager;
    private SkinManager skinManager;
    private CombatManager combatManager;
    private PathfindingManager pathfindingManager;
    private MovementManager movementManager;
    private PatrolManager patrolManager;
    private GuardManager guardManager;
    private BuildManager buildManager;
    private EffectsManager effectsManager;
    private TeamManager teamManager;
    private NPCInventoryGUI inventoryGUI;
    private NPCTickService npcTickService;
    
    @Override
    public void onEnable() {
        instance = this;
        
        saveDefaultConfig();
        
        initializeManagers();
        registerCommands();
        startServices();
        
        getLogger().info("WarriorNPC enabled successfully!");
    }
    
    @Override
    public void onDisable() {
        if (npcTickService != null) {
            npcTickService.stop();
        }
        if (npcManager != null) {
            npcManager.saveAll();
            npcManager.removeAll();
        }
        getLogger().info("WarriorNPC disabled.");
    }
    
    private void initializeManagers() {
        configManager = new ConfigManager(this);
        messageManager = new MessageManager(this);
        skinManager = new SkinManager(this);
        pathfindingManager = new PathfindingManager(this);
        movementManager = new MovementManager(this);
        combatManager = new CombatManager(this);
        patrolManager = new PatrolManager(this);
        guardManager = new GuardManager(this);
        buildManager = new BuildManager(this);
        effectsManager = new EffectsManager(this);
        teamManager = new TeamManager(this);
        inventoryGUI = new NPCInventoryGUI(this);
        npcManager = new NPCManager(this);
    }
    
    private void registerCommands() {
        getCommand("wnpc").setExecutor(new NPCCommandExecutor(this));
        getCommand("wnpc").setTabCompleter(new NPCTabCompleter(this));
        
        // Register listeners
        getServer().getPluginManager().registerEvents(new NPCDeathListener(this), this);
        getServer().getPluginManager().registerEvents(new NPCPickupListener(this), this);
        getServer().getPluginManager().registerEvents(new com.spacygaming.warriornpc.listeners.NPCDamageListener(this), this);
        getServer().getPluginManager().registerEvents(inventoryGUI, this);
    }
    
    private void startServices() {
        npcTickService = new NPCTickService(this);
        npcTickService.start();
        
        // Check if NPCs need to be resumed and notify admins
        getServer().getScheduler().runTaskLater(this, () -> {
            if (!npcManager.hasResumed() && !npcManager.getAllNPCs().isEmpty()) {
                for (org.bukkit.entity.Player player : getServer().getOnlinePlayers()) {
                    if (player.hasPermission("warriornpc.admin")) {
                        player.sendMessage("§e§l⚠ WarriorNPC Plugin Loaded");
                        player.sendMessage("§7Use §e/wnpc resumeallnpc §7to restore all saved NPCs");
                    }
                }
            }
        }, 40L);
        
        // Auto-save every 5 minutes
        getServer().getScheduler().runTaskTimer(this, () -> {
            npcManager.saveAll();
        }, 6000L, 6000L);
    }
    
    public void reload() {
        reloadConfig();
        configManager.reload();
        messageManager.reload();
    }
    
    public static WarriorNPCPlugin getInstance() {
        return instance;
    }
    
    public ConfigManager getConfigManager() {
        return configManager;
    }
    
    public MessageManager getMessageManager() {
        return messageManager;
    }
    
    public NPCManager getNpcManager() {
        return npcManager;
    }
    
    public SkinManager getSkinManager() {
        return skinManager;
    }
    
    public CombatManager getCombatManager() {
        return combatManager;
    }
    
    public PathfindingManager getPathfindingManager() {
        return pathfindingManager;
    }
    
    public PatrolManager getPatrolManager() {
        return patrolManager;
    }
    
    public BuildManager getBuildManager() {
        return buildManager;
    }
    
    public EffectsManager getEffectsManager() {
        return effectsManager;
    }
    
    public MovementManager getMovementManager() {
        return movementManager;
    }
    
    public NPCInventoryGUI getInventoryGUI() {
        return inventoryGUI;
    }
    
    public GuardManager getGuardManager() {
        return guardManager;
    }
    
    public TeamManager getTeamManager() {
        return teamManager;
    }
}

# WarriorNPC - Build & Deployment Guide

## Project Structure
```
NpcGuard/
├── src/main/
│   ├── java/com/spacygaming/warriornpc/
│   │   ├── WarriorNPCPlugin.java          (Main plugin class)
│   │   ├── combat/
│   │   │   └── FightStyle.java            (Fight style enum)
│   │   ├── commands/
│   │   │   └── NPCCommandExecutor.java    (All commands)
│   │   ├── managers/
│   │   │   ├── BuildManager.java          (Structure building)
│   │   │   ├── CombatManager.java         (Combat AI)
│   │   │   ├── ConfigManager.java         (Configuration)
│   │   │   ├── MessageManager.java        (Messages)
│   │   │   ├── NPCManager.java            (NPC lifecycle)
│   │   │   ├── PathfindingManager.java    (Navigation)
│   │   │   ├── PatrolManager.java         (Patrol system)
│   │   │   └── SkinManager.java           (Mojang skins)
│   │   ├── models/
│   │   │   ├── NPCData.java               (NPC data model)
│   │   │   └── SkinData.java              (Skin data model)
│   │   └── services/
│   │       └── NPCTickService.java        (AI tick loop)
│   └── resources/
│       ├── plugin.yml                      (Plugin metadata)
│       ├── config.yml                      (Configuration)
│       ├── messages.yml                    (Messages)
│       └── npcs.yml                        (NPC data template)
├── pom.xml                                 (Maven build file)
├── README.md                               (Documentation)
└── .gitignore                              (Git ignore rules)
```

## Build Instructions

### Prerequisites
1. **Java Development Kit 21**
   - Download from: https://adoptium.net/
   - Verify: `java -version` (should show 21.x.x)

2. **Apache Maven 3.6+**
   - Download from: https://maven.apache.org/download.cgi
   - Verify: `mvn -version`

3. **Paper Server 1.21+**
   - Download from: https://papermc.io/downloads/paper

### Compile the Plugin

#### Windows
```cmd
cd c:\Users\Chetan\Desktop\desktopdata\SpacyPlugins\NpcGuard
mvn clean package
```

#### Linux/Mac
```bash
cd /path/to/NpcGuard
mvn clean package
```

### Build Output
- Compiled JAR: `target/WarriorNPC-1.0.0.jar`
- This is a shaded JAR with all dependencies included

## Deployment

### Server Setup
1. Copy `target/WarriorNPC-1.0.0.jar` to your server's `plugins/` folder
2. Start the Paper server
3. Plugin will auto-generate configuration files in `plugins/WarriorNPC/`

### Configuration Files Generated
- `plugins/WarriorNPC/config.yml` - Main configuration
- `plugins/WarriorNPC/messages.yml` - Customizable messages
- `plugins/WarriorNPC/npcs.yml` - NPC persistent storage

## Quick Start Guide

### Basic Usage

1. **Spawn an NPC**
   ```
   /wnpc spawn Notch
   ```

2. **Make it patrol**
   ```
   /wnpc patrol Notch add      (at waypoint 1)
   /wnpc patrol Notch add      (at waypoint 2)
   /wnpc patrol Notch add      (at waypoint 3)
   /wnpc patrol Notch start
   ```

3. **Give it equipment**
   ```
   Hold a diamond sword
   /wnpc wear Notch hand
   
   Hold diamond armor
   /wnpc wear Notch helmet
   /wnpc wear Notch chest
   /wnpc wear Notch legs
   /wnpc wear Notch boots
   ```

4. **Set combat style**
   ```
   /wnpc style Notch attack LT3
   /wnpc style Notch defense LT4
   ```

5. **Make it fight**
   ```
   /wnpc attack Notch Steve
   ```

### Team Battle Example
```
/wnpc spawn RedTeam1
/wnpc spawn RedTeam2
/wnpc spawn BlueTeam1
/wnpc spawn BlueTeam2

/wnpc fight team:RedTeam1,RedTeam2 vs team:BlueTeam1,BlueTeam2
```

### Building Example
```
/wnpc spawn Builder
/wnpc build Builder castle
```

## Technical Features Implemented

### ✅ Complete Features
- [x] Maven project structure (Java 21, Paper 1.21+)
- [x] Plugin configuration system
- [x] Message management system
- [x] NPC spawning with player entities
- [x] Mojang skin loading (async with caching)
- [x] Advanced pathfinding with obstacle avoidance
- [x] Combat AI with fight styles (LT1-5, HT1-5)
- [x] Team-based combat
- [x] Duel system
- [x] Patrol system with waypoints
- [x] Guard mode
- [x] Follow system
- [x] Structure building (4 types)
- [x] Equipment system
- [x] AI control (start/stop)
- [x] Persistent storage (YAML)
- [x] All 30+ commands implemented
- [x] Performance optimizations

### Combat Features
- Smart target selection
- Line of sight checking
- Strafing movement
- Sprint mechanics
- Critical hit simulation
- Shield usage
- Attack cooldowns
- Team recognition
- No friendly fire option

### Pathfinding Features
- Obstacle detection and avoidance
- Door opening support
- Water/lava avoidance
- Cliff detection
- Alternative path finding
- Smooth rotation and movement

## Performance Specifications

- **Maximum NPCs**: 200 (configurable)
- **Tick Interval**: 1 tick (configurable)
- **Async Operations**: Skin loading, file saving
- **Memory**: Optimized with concurrent data structures
- **TPS Impact**: Minimal with 50+ NPCs

## Troubleshooting

### Build Issues
```bash
# Clean Maven cache
mvn clean

# Force update dependencies
mvn clean package -U
```

### Common Runtime Issues
1. **NPCs not spawning**: Check max-npcs in config.yml
2. **Skins not loading**: Verify internet connection and Mojang API access
3. **Pathfinding issues**: Adjust recalculate-ticks in config.yml
4. **Performance**: Increase tick-interval or reduce max-npcs

## Development Notes

### Code Structure
- **Service-based architecture**: Each major feature has its own manager
- **Event-driven**: Uses Bukkit scheduler for AI ticks
- **Thread-safe**: ConcurrentHashMap for shared data
- **Clean separation**: Models, managers, services, commands

### Extension Points
- Add new fight styles in `FightStyle.java`
- Add new build types in `BuildManager.java`
- Customize messages in `messages.yml`
- Adjust AI behavior in manager classes

## Credits
- **Author**: SpacyGaming
- **Platform**: PaperMC 1.21+
- **Java Version**: 21
- **Build System**: Maven

---

**Project Status**: ✅ Production Ready
**Last Updated**: 2024

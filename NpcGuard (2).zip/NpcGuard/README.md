# WarriorNPC (WNPC)

**Author:** SpacyGaming  
**Platform:** Minecraft Java Edition - PaperMC 1.21+  
**Java:** 21  
**Build System:** Maven

## Overview

WarriorNPC is an advanced AI NPC combat and automation plugin for PaperMC servers. It allows server administrators to create realistic player-like NPCs that can walk, fight, patrol, build structures, and participate in complex combat scenarios.

## Features

### Core Features
- ✅ Realistic player-like NPC entities
- ✅ Mojang skin support (auto-download from usernames)
- ✅ Advanced pathfinding with obstacle avoidance
- ✅ Sophisticated PvP combat AI
- ✅ Multiple fight styles (LT1-5, HT1-5)
- ✅ Team-based combat system
- ✅ Patrol system with unlimited waypoints
- ✅ Guard mode for area defense
- ✅ Follow system
- ✅ Structure building (house, castle, tower, shelter)
- ✅ Full equipment system
- ✅ Persistent NPC data storage

### Combat System
- Smart targeting and aggro management
- Realistic strafe movement
- Sprint mechanics
- Critical hit timing
- Shield usage
- Line of sight detection
- Team recognition (no friendly fire)
- Attack cooldown simulation
- Multiple fight styles with different CPS and behavior

### Fight Styles

#### Low Tick (LT) Styles
- **LT5**: Fast CPS (18), heavy defense, frequent shield usage
- **LT4**: Fast CPS (16), balanced combat
- **LT3**: Offensive fighter (14 CPS)
- **LT2**: Very aggressive (12 CPS)
- **LT1**: Hyper aggressive (20 CPS), almost never blocks

#### High Tick (HT) Styles
- **HT5**: Fully charged attacks (2 CPS), maximum defense
- **HT4**: Strong defense (3 CPS)
- **HT3**: Balanced (5 CPS)
- **HT2**: Offensive (7 CPS)
- **HT1**: Full offense (10 CPS), never defends

## Building the Plugin

### Prerequisites
- Java 21 JDK
- Maven 3.6+
- PaperMC 1.21+ server

### Compile
```bash
mvn clean package
```

The compiled JAR will be in `target/WarriorNPC-1.0.0.jar`

## Installation

1. Download or compile the plugin JAR
2. Place in your server's `plugins/` folder
3. Start/restart the server
4. Configure in `plugins/WarriorNPC/config.yml`

## Commands

All commands use `/wnpc` with aliases `/wn` and `/rgnpc`

### NPC Management
- `/wnpc spawn <name>` - Spawn an NPC at your location
- `/wnpc remove <npc>` - Remove an NPC
- `/wnpc list` - List all NPCs
- `/wnpc info <npc>` - Show NPC information
- `/wnpc rename <npc> <displayname>` - Rename an NPC
- `/wnpc reset <npc>` - Reset NPC to default state

### Movement
- `/wnpc tp <npc> <x> <y> <z>` - Teleport NPC to coordinates
- `/wnpc tphere <npc>` - Teleport NPC to your location
- `/wnpc goto <npc> <x> <y> <z>` - Make NPC walk to coordinates
- `/wnpc follow <npc> <target>` - Make NPC follow target

### Combat
- `/wnpc attack <npc> <target> [target...]` - Attack specified targets
- `/wnpc duel <npc1> <npc2>` - Start a duel between two NPCs
- `/wnpc fight team:npc1,npc2 vs team:npc3,npc4` - Team battle
- `/wnpc style <npc> attack <style>` - Set attack style
- `/wnpc style <npc> defense <style>` - Set defense style

### Tasks
- `/wnpc guard <npc> [radius]` - Guard current location
- `/wnpc patrol <npc> add` - Add patrol waypoint at your location
- `/wnpc patrol <npc> start` - Start patrolling
- `/wnpc patrol <npc> list` - List waypoints
- `/wnpc patrol <npc> clear` - Clear all waypoints
- `/wnpc build <npc> <type>` - Build structure (house/castle/tower/shelter)

### Equipment
- `/wnpc wear <npc> hand` - Equip held item to main hand
- `/wnpc wear <npc> offhand` - Equip to offhand
- `/wnpc wear <npc> helmet` - Equip to helmet slot
- `/wnpc wear <npc> chest` - Equip to chestplate slot
- `/wnpc wear <npc> legs` - Equip to leggings slot
- `/wnpc wear <npc> boots` - Equip to boots slot
- `/wnpc clearwear <npc>` - Remove all equipment

### AI Control
- `/wnpc start <npc|all>` - Enable AI for NPC(s)
- `/wnpc stop <npc|all>` - Disable AI for NPC(s)

### Skin & System
- `/wnpc reloadskin <npc>` - Reload NPC skin from Mojang
- `/wnpc reload` - Reload plugin configuration

## Configuration

### config.yml
```yaml
npc:
  default-health: 20.0
  name-visible: true
  name-visible-range: 48.0

combat:
  attack-range: 3.5
  chase-range: 20.0
  los-check: true
  friendly-fire: false

pathfinding:
  recalculate-ticks: 10
  max-path-distance: 64.0
  avoid-water: true
  open-doors: true

performance:
  max-npcs: 200
  tick-interval: 1
  async-skin-loading: true
  async-file-saving: true

skin:
  cache-enabled: true
  cache-duration-hours: 24
```

## Permissions

- `warriornpc.use` - Access to all commands (default: op)
- `warriornpc.admin` - Full administrative access (default: op)

## Data Storage

All NPC data is stored in YAML format:
- `plugins/WarriorNPC/npcs.yml` - NPC persistent data
- `plugins/WarriorNPC/config.yml` - Plugin configuration
- `plugins/WarriorNPC/messages.yml` - Customizable messages

## Performance

Optimized for large servers:
- Support for 200+ NPCs simultaneously
- Async skin loading
- Async file operations
- Configurable tick intervals
- Minimal packet usage
- TPS-friendly pathfinding

## Technical Details

### Architecture
- Service-based design
- Event-driven system
- Clean OOP structure
- Manager pattern for subsystems
- Concurrent data structures for thread safety

### Key Components
- **NPCManager**: Core NPC spawning and lifecycle
- **SkinManager**: Mojang API integration with caching
- **PathfindingManager**: Advanced navigation system
- **CombatManager**: PvP AI and fight mechanics
- **PatrolManager**: Waypoint-based patrol logic
- **BuildManager**: Structure building automation
- **NPCTickService**: Centralized AI update loop

## Support

For issues, suggestions, or contributions:
- Plugin by SpacyGaming
- Built for PaperMC 1.21+
- Java 21 required

## License

All rights reserved - SpacyGaming

---

**Version:** 1.0.0  
**Last Updated:** 2024

# WarriorNPC - Quick Command Reference

## 🎮 Command Aliases
- `/wnpc` (main)
- `/wn` (short)
- `/rgnpc` (alternative)

---

## 📋 NPC Management

| Command | Description | Example |
|---------|-------------|---------|
| `spawn <name>` | Spawn NPC at your location | `/wnpc spawn Steve` |
| `remove <npc>` | Remove an NPC | `/wnpc remove Steve` |
| `list` | List all NPCs | `/wnpc list` |
| `info <npc>` | Show NPC details | `/wnpc info Steve` |
| `rename <npc> <name>` | Change display name | `/wnpc rename Steve Herobrine` |
| `reset <npc>` | Reset NPC to idle state | `/wnpc reset Steve` |

---

## 🚶 Movement & Navigation

| Command | Description | Example |
|---------|-------------|---------|
| `tp <npc> <x> <y> <z>` | Teleport NPC | `/wnpc tp Steve 100 64 200` |
| `tphere <npc>` | Teleport NPC to you | `/wnpc tphere Steve` |
| `goto <npc> <x> <y> <z>` | Walk to coordinates | `/wnpc goto Steve 100 64 200` |
| `follow <npc> <target>` | Follow player/NPC | `/wnpc follow Steve Alex` |

---

## ⚔️ Combat

| Command | Description | Example |
|---------|-------------|---------|
| `attack <npc> <target...>` | Attack targets | `/wnpc attack Steve Zombie Alex` |
| `duel <npc1> <npc2>` | Start 1v1 duel | `/wnpc duel Steve Alex` |
| `fight team:... vs team:...` | Team battle | `/wnpc fight team:S1,S2 vs team:A1,A2` |
| `style <npc> attack <style>` | Set attack style | `/wnpc style Steve attack LT3` |
| `style <npc> defense <style>` | Set defense style | `/wnpc style Steve defense HT2` |

### Available Styles
**Low Tick (Fast):** LT5, LT4, LT3, LT2, LT1  
**High Tick (Charged):** HT5, HT4, HT3, HT2, HT1

---

## 🛡️ Tasks & Behaviors

| Command | Description | Example |
|---------|-------------|---------|
| `guard <npc> [radius]` | Guard area | `/wnpc guard Steve 15` |
| `patrol <npc> add` | Add waypoint | `/wnpc patrol Steve add` |
| `patrol <npc> start` | Start patrol | `/wnpc patrol Steve start` |
| `patrol <npc> list` | List waypoints | `/wnpc patrol Steve list` |
| `patrol <npc> clear` | Clear waypoints | `/wnpc patrol Steve clear` |

---

## 🏗️ Building

| Command | Description | Example |
|---------|-------------|---------|
| `build <npc> house` | Build a house | `/wnpc build Steve house` |
| `build <npc> castle` | Build a castle | `/wnpc build Steve castle` |
| `build <npc> tower` | Build a tower | `/wnpc build Steve tower` |
| `build <npc> shelter` | Build a shelter | `/wnpc build Steve shelter` |

---

## 👔 Equipment

| Command | Description | Example |
|---------|-------------|---------|
| `wear <npc> hand` | Equip to main hand | `/wnpc wear Steve hand` |
| `wear <npc> offhand` | Equip to offhand | `/wnpc wear Steve offhand` |
| `wear <npc> helmet` | Equip helmet | `/wnpc wear Steve helmet` |
| `wear <npc> chest` | Equip chestplate | `/wnpc wear Steve chest` |
| `wear <npc> legs` | Equip leggings | `/wnpc wear Steve legs` |
| `wear <npc> boots` | Equip boots | `/wnpc wear Steve boots` |
| `clearwear <npc>` | Remove all equipment | `/wnpc clearwear Steve` |

**Note:** Hold the item you want to equip, then run the command

---

## 🎛️ AI Control

| Command | Description | Example |
|---------|-------------|---------|
| `start <npc>` | Enable AI | `/wnpc start Steve` |
| `start all` | Enable all NPCs | `/wnpc start all` |
| `stop <npc>` | Disable AI | `/wnpc stop Steve` |
| `stop all` | Disable all NPCs | `/wnpc stop all` |

---

## 🎨 Appearance

| Command | Description | Example |
|---------|-------------|---------|
| `reloadskin <npc>` | Reload Mojang skin | `/wnpc reloadskin Steve` |

**Note:** Skin is auto-loaded when NPC is spawned with that name

---

## ⚙️ System

| Command | Description | Example |
|---------|-------------|---------|
| `reload` | Reload configuration | `/wnpc reload` |

---

## 🎯 Quick Usage Examples

### Example 1: Create Fighting NPC
```
/wnpc spawn Warrior
/wnpc wear Warrior hand          (hold diamond sword)
/wnpc wear Warrior helmet        (hold diamond helmet)
/wnpc style Warrior attack LT3
/wnpc attack Warrior Zombie
```

### Example 2: Create Patrol Guard
```
/wnpc spawn Guard
/wnpc patrol Guard add           (at corner 1)
/wnpc patrol Guard add           (at corner 2)
/wnpc patrol Guard add           (at corner 3)
/wnpc patrol Guard add           (at corner 4)
/wnpc patrol Guard start
```

### Example 3: Team Battle
```
/wnpc spawn RedTeam1
/wnpc spawn RedTeam2
/wnpc spawn BlueTeam1
/wnpc spawn BlueTeam2
/wnpc fight team:RedTeam1,RedTeam2 vs team:BlueTeam1,BlueTeam2
```

### Example 4: Builder NPC
```
/wnpc spawn Builder
/wnpc goto Builder 100 64 200    (walk to build site)
/wnpc build Builder castle
```

### Example 5: Follower NPC
```
/wnpc spawn Companion
/wnpc follow Companion PlayerName
```

---

## 🔑 Permissions

| Permission | Description |
|------------|-------------|
| `warriornpc.use` | All commands (default: op) |
| `warriornpc.admin` | Full access (default: op) |

---

## 📊 Fight Style Comparison

| Style | CPS | Aggression | Defense | Best For |
|-------|-----|------------|---------|----------|
| **LT1** | 20 | ⭐⭐⭐⭐⭐ | ⭐ | Overwhelming offense |
| **LT2** | 12 | ⭐⭐⭐⭐ | ⭐⭐ | Aggressive combat |
| **LT3** | 14 | ⭐⭐⭐ | ⭐⭐⭐ | Balanced fast fighting |
| **LT4** | 16 | ⭐⭐⭐ | ⭐⭐⭐⭐ | Defensive fast fighter |
| **LT5** | 18 | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ | Maximum defense |
| **HT1** | 10 | ⭐⭐⭐⭐⭐ | ⭐ | Full power offense |
| **HT2** | 7 | ⭐⭐⭐⭐ | ⭐⭐ | Strong offense |
| **HT3** | 5 | ⭐⭐⭐ | ⭐⭐⭐ | Balanced power |
| **HT4** | 3 | ⭐⭐ | ⭐⭐⭐⭐ | Tank with power |
| **HT5** | 2 | ⭐ | ⭐⭐⭐⭐⭐ | Ultimate tank |

---

## 💡 Pro Tips

1. **NPCs auto-save** - All changes persist through restarts
2. **Skins cache** - First load may be slow, then instant
3. **AI toggles** - Use stop/start to freeze NPCs temporarily
4. **Team fights** - No friendly fire within teams
5. **Equipment saves** - NPCs keep gear after restart
6. **Multiple targets** - Attack command accepts multiple targets
7. **Patrol loops** - Patrols automatically loop waypoints
8. **Guard radius** - Larger radius = bigger patrol area

---

## 🆘 Troubleshooting

| Issue | Solution |
|-------|----------|
| NPC won't spawn | Check max-npcs in config.yml |
| Skin not loading | Check internet, wait for async load |
| NPC not moving | Use `/wnpc start <npc>` to enable AI |
| Combat not working | Check if target is in range and AI is enabled |
| Equipment not showing | Equipment applies immediately, try relogging |

---

**Plugin:** WarriorNPC v1.0.0  
**Author:** SpacyGaming  
**For:** PaperMC 1.21+ / Java 21

# WarriorNPC - Complete Project Tree

```
NpcGuard/
│
├── 📄 pom.xml                              # Maven build configuration (Java 21, Paper 1.21.4)
├── 📄 .gitignore                           # Git ignore rules
├── 📄 README.md                            # Main documentation
├── 📄 BUILD_GUIDE.md                       # Build & deployment instructions
├── 📄 PROJECT_SUMMARY.md                   # Complete feature checklist
│
└── src/main/
    │
    ├── java/com/spacygaming/warriornpc/
    │   │
    │   ├── 📄 WarriorNPCPlugin.java        # ⭐ Main plugin class
    │   │                                    #    - Service initialization
    │   │                                    #    - Command registration
    │   │                                    #    - Plugin lifecycle
    │   │
    │   ├── 📁 combat/
    │   │   └── 📄 FightStyle.java          # Fight style enum (LT1-5, HT1-5)
    │   │                                    #    - CPS rates
    │   │                                    #    - Aggression levels
    │   │                                    #    - Defense frequencies
    │   │
    │   ├── 📁 commands/
    │   │   └── 📄 NPCCommandExecutor.java  # ⭐ All 34 commands
    │   │                                    #    - spawn, remove, list, info
    │   │                                    #    - tp, tphere, goto, follow
    │   │                                    #    - attack, duel, fight
    │   │                                    #    - guard, patrol, build
    │   │                                    #    - style, wear, start/stop
    │   │                                    #    - rename, reloadskin, reset
    │   │
    │   ├── 📁 managers/
    │   │   ├── 📄 ConfigManager.java       # Configuration handling
    │   │   │                                #    - All config values
    │   │   │                                #    - Reload support
    │   │   │
    │   │   ├── 📄 MessageManager.java      # Message system
    │   │   │                                #    - Placeholder replacement
    │   │   │                                #    - Color codes
    │   │   │
    │   │   ├── 📄 NPCManager.java          # ⭐ Core NPC management
    │   │   │                                #    - Spawn/remove NPCs
    │   │   │                                #    - Persistence (save/load)
    │   │   │                                #    - Skin application
    │   │   │                                #    - Entity management
    │   │   │
    │   │   ├── 📄 SkinManager.java         # Mojang skin integration
    │   │   │                                #    - Async API calls
    │   │   │                                #    - Skin caching
    │   │   │                                #    - UUID lookup
    │   │   │
    │   │   ├── 📄 PathfindingManager.java  # ⭐ Navigation system
    │   │   │                                #    - Obstacle avoidance
    │   │   │                                #    - Path calculation
    │   │   │                                #    - Smooth movement
    │   │   │
    │   │   ├── 📄 CombatManager.java       # ⭐ Combat AI
    │   │   │                                #    - Target selection
    │   │   │                                #    - Attack execution
    │   │   │                                #    - Team management
    │   │   │                                #    - Fight styles
    │   │   │                                #    - Strafing & sprinting
    │   │   │
    │   │   ├── 📄 PatrolManager.java       # Patrol system
    │   │   │                                #    - Waypoint management
    │   │   │                                #    - Loop patrolling
    │   │   │
    │   │   └── 📄 BuildManager.java        # Structure building
    │   │                                    #    - House, Castle, Tower, Shelter
    │   │                                    #    - Gradual placement
    │   │
    │   ├── 📁 models/
    │   │   ├── 📄 NPCData.java             # ⭐ NPC data model
    │   │   │                                #    - UUID, name, location
    │   │   │                                #    - Health, equipment
    │   │   │                                #    - Task, styles, waypoints
    │   │   │
    │   │   └── 📄 SkinData.java            # Skin data model
    │   │                                    #    - Texture, signature
    │   │                                    #    - Cache timestamp
    │   │
    │   ├── 📁 services/
    │   │   └── 📄 NPCTickService.java      # ⭐ Central AI loop
    │   │                                    #    - Scheduled task
    │   │                                    #    - Tick all NPCs
    │   │                                    #    - Task routing
    │   │
    │   └── 📁 utils/
    │       └── 📄 NPCUtils.java            # Helper utilities
    │                                        #    - Line of sight
    │                                        #    - Direction calculation
    │                                        #    - Distance checks
    │
    └── resources/
        ├── 📄 plugin.yml                   # Plugin metadata
        │                                    #    - Commands & aliases
        │                                    #    - Permissions
        │                                    #    - API version
        │
        ├── 📄 config.yml                   # Main configuration
        │                                    #    - NPC settings
        │                                    #    - Combat settings
        │                                    #    - Pathfinding settings
        │                                    #    - Performance settings
        │                                    #    - Skin settings
        │
        ├── 📄 messages.yml                 # All plugin messages
        │                                    #    - Customizable text
        │                                    #    - Color codes
        │                                    #    - Placeholders
        │
        └── 📄 npcs.yml                     # NPC data storage template
                                             #    - Auto-generated
                                             #    - Persistent storage

```

## 📊 File Statistics

| Category | Count | Purpose |
|----------|-------|---------|
| **Java Files** | 14 | Core plugin logic |
| **Config Files** | 4 | Configuration & messages |
| **Build Files** | 2 | Maven POM & gitignore |
| **Documentation** | 3 | README, guides, summary |
| **Total Files** | 23 | Complete project |

## 🎯 Key Components Explained

### ⭐ Critical Files (Must Read)
1. **WarriorNPCPlugin.java** - Plugin entry point, initializes everything
2. **NPCManager.java** - Spawns NPCs, handles persistence, applies skins
3. **CombatManager.java** - All combat logic, fight styles, targeting
4. **PathfindingManager.java** - Makes NPCs walk realistically
5. **NPCTickService.java** - Updates all NPCs every tick
6. **NPCCommandExecutor.java** - Processes all player commands
7. **NPCData.java** - Stores all NPC information

### 🔧 Supporting Systems
- **SkinManager** - Downloads skins from Mojang
- **PatrolManager** - Handles waypoint patrols
- **BuildManager** - Automates structure building
- **ConfigManager** - Reads config.yml
- **MessageManager** - Sends formatted messages

### 📦 Data Models
- **NPCData** - Complete NPC state
- **SkinData** - Cached skin information
- **FightStyle** - Combat behavior configurations

### 🛠️ Utilities
- **NPCUtils** - Helper functions for math and checks

## 🚀 Quick Start

### Build Command
```bash
mvn clean package
```

### Output Location
```
target/WarriorNPC-1.0.0.jar
```

### Installation
1. Copy JAR to server `plugins/` folder
2. Start server (Paper 1.21+)
3. Use `/wnpc` commands

## 📝 Example Usage Flow

```
Player: /wnpc spawn Steve
  ↓
NPCCommandExecutor.handleSpawn()
  ↓
NPCManager.createNPC()
  ↓
SkinManager.loadSkin() [async]
  ↓
NPCManager.spawnNPC()
  ↓
NPCTickService starts updating NPC
  ↓
NPC appears in game with skin!
```

---

**Project Status:** ✅ **COMPLETE**  
**Total Development:** ~3000+ lines of production code  
**Ready for:** PaperMC 1.21+ servers with Java 21
